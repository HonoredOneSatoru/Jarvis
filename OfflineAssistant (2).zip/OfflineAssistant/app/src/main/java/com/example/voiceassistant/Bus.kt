package com.example.voiceassistant

/** Message board between the background service and the screen. */
object Bus {
    val lines = ArrayList<String>()
    @Volatile var total = 0
    @Volatile var statusText = "Stopped"
    @Volatile var brainError: String? = null
    @Volatile var listener: (() -> Unit)? = null

    fun log(line: String) {
        synchronized(lines) {
            lines.add(line)
            total++
            while (lines.size > 200) lines.removeAt(0)
        }
        listener?.invoke()
    }

    fun setStatus(s: String) {
        statusText = s
        listener?.invoke()
    }
}
