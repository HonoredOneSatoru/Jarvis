package com.example.voiceassistant

import android.content.Context

/** Fixed tuning lives here; things you can change on the phone live in Settings (menu, top right). */
object Config {
    // ---------------------------------------------------------------- persona
    @Volatile var persona = "neko"                       // "neko" (anime girl) or "jarvis" (British butler)
    val name: String get() = if (persona == "jarvis") "Jarvis" else "Neko"
    val addr: String get() = if (persona == "jarvis") "sir" else "senpai"

    private const val MATH_RULES =
        "When the user asks a maths question, act as a patient, excellent maths teacher. " +
        "Solve it step by step: say Step 1, Step 2 and so on, one short sentence per step, " +
        "then finish with: So the answer is, followed by the result. " +
        "Write every formula in plain words so it can be read aloud: say one half, x over two, x squared, " +
        "square root of nine, times, divided by, equals. " +
        "NEVER use dollar signs, backslashes, LaTeX, carets or markdown in your answers. " +
        "Check your arithmetic before you answer."

    private const val NEKO_PROMPT =
        "You are Neko, a cheerful, kind and playful anime-style cat-girl AI assistant living on the user's phone. " +
        "Always call the user senpai. Speak warmly and naturally, with an occasional nya, but do not overdo it. " +
        "Reply in one to three short spoken sentences, except when teaching maths. " +
        "Never use emojis or markdown. If you do not know something, say so plainly and never invent facts. " +
        "You run fully offline on the phone, so you cannot browse the internet or know today's news."

    private const val JARVIS_PROMPT =
        "You are J.A.R.V.I.S., a calm, impeccably polite British AI butler with dry wit. " +
        "Always address the user as sir. Reply in one to three short spoken sentences, except when teaching maths. " +
        "Never use emojis or markdown. If you do not know something, say so plainly and never invent facts. " +
        "You run fully offline on the user's phone, so you cannot browse the internet or know today's news."

    val systemPrompt: String get() = (if (persona == "jarvis") JARVIS_PROMPT else NEKO_PROMPT) + " " + MATH_RULES

    val visionPrompt: String
        get() = "You are $name, a friendly AI assistant. The user shows you a photo. Look carefully and answer their " +
            "question in at most five short spoken sentences, plain text only, addressing them as ${addr}. " +
            "If there is text in the image, read out the important parts. If you are unsure, say so."

    // ---------------------------------------------------------------- wake word
    private val JARVIS_RE = Regex("\\b(jarvis|jarvas|jarvus|jarves|garvis|travis|jar vis|java's)\\b")
    private val NEKO_RE = Regex("\\b(neko|nekko|neeko|nico|niko|nika|nay ko|nay co|neck oh|nec oh|neck o|nako|necko)\\b")
    val wakeRegex: Regex get() = if (persona == "jarvis") JARVIS_RE else NEKO_RE
    val wakeWord: String get() = if (persona == "jarvis") "jarvis" else "neko"

    // ---------------------------------------------------------------- tuning
    const val UNLOAD_BRAIN_AFTER_MINUTES = 240            // the brain only needs ~700 MB, so keep it ready
    const val AWAKE_SECONDS = 8
    const val HISTORY_TURNS = 4

    // ---- changeable in the app: Settings ----
    @Volatile var voiceId = 4             // 4 Sky, 1 Bella (US girls) · 7 Emma, 8 Isabella (UK girls) · 9 George, 10 Lewis (UK men)
    @Volatile var voiceSpeed = 1.0f
    @Volatile var voicePitch = 1.15f      // above 1 = higher, cuter voice (1.0 = natural)
    @Volatile var wakeMaxDist = 2         // 1 strict, 2 normal, 3 forgiving
    @Volatile var musicApp = "com.spotify.music"
    @Volatile var confirmCalls = true
    @Volatile var confirmTexts = true

    fun applyPersona(p: String) {
        persona = p
        if (p == "jarvis") { voiceId = 9; voiceSpeed = 0.97f; voicePitch = 1.0f }
        else { voiceId = 4; voiceSpeed = 1.0f; voicePitch = 1.15f }
    }

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("jarvis_cfg", Context.MODE_PRIVATE)
        if (p.contains("persona")) {
            persona = p.getString("persona", "neko") ?: "neko"
            voiceId = p.getInt("voice", voiceId)
            voiceSpeed = p.getFloat("speed", voiceSpeed)
            voicePitch = p.getFloat("pitch", voicePitch)
        } else {
            applyPersona("neko")               // first launch of this version: Neko with her anime voice
        }
        wakeMaxDist = p.getInt("wake", wakeMaxDist)
        musicApp = p.getString("music", musicApp) ?: musicApp
        confirmCalls = p.getBoolean("confirmCalls", confirmCalls)
        confirmTexts = p.getBoolean("confirmTexts", confirmTexts)
        if (!p.contains("persona")) save(ctx)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences("jarvis_cfg", Context.MODE_PRIVATE).edit()
            .putString("persona", persona)
            .putInt("voice", voiceId)
            .putFloat("speed", voiceSpeed)
            .putFloat("pitch", voicePitch)
            .putInt("wake", wakeMaxDist)
            .putString("music", musicApp)
            .putBoolean("confirmCalls", confirmCalls)
            .putBoolean("confirmTexts", confirmTexts)
            .apply()
    }
}

object Wake {
    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    /** Index just after the wake word in [t], or -1 if it was not said. */
    fun find(t: String): Int {
        Config.wakeRegex.find(t)?.let { return it.range.last + 1 }
        val word = Config.wakeWord
        val maxDist = if (word.length <= 4) 1 else Config.wakeMaxDist
        val parts = t.split(" ").filter { it.isNotEmpty() }
        val starts = ArrayList<Int>()
        var from = 0
        for (p in parts) {
            val at = t.indexOf(p, from)
            starts.add(at)
            from = at + p.length
        }
        for (i in parts.indices) {
            val w = parts[i]
            if (w.length >= 4 && lev(w, word) <= maxDist) return starts[i] + w.length
            if (i + 1 < parts.size) {
                val j = w + parts[i + 1]
                if (j.length >= 4 && lev(j, word) <= maxDist) return starts[i + 1] + parts[i + 1].length
            }
        }
        return -1
    }
}
