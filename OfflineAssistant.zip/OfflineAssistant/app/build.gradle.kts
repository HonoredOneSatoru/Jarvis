plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.voiceassistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.voiceassistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += "arm64-v8a" }   // S26 Ultra is arm64 only
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        resources {
            excludes += listOf("META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES", "META-INF/INDEX.LIST", "META-INF/*.md")
        }
        jniLibs {
            pickFirsts += listOf("**/libc++_shared.so", "**/libjnidispatch.so")
        }
    }
}

dependencies {
    // Ears (offline speech-to-text)
    implementation("com.alphacephei:vosk-android:0.3.47")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    // Voice engine. The build downloads this file into app/libs automatically (see .github/workflows/build.yml)
    implementation(files("libs/sherpa-onnx.aar"))
    // Brain (offline LLM)
    implementation("com.google.mediapipe:tasks-genai:0.10.33")
    // Unpacks the voice download (.tar.bz2)
    implementation("org.apache.commons:commons-compress:1.26.2")
}
