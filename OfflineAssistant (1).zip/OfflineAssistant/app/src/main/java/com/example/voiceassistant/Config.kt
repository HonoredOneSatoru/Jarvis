package com.example.voiceassistant

import android.content.Context

/** Fixed tuning lives here; things you can change on the phone live in Settings (menu, top right). */
object Config {
    val SYSTEM_PROMPT =
        "You are J.A.R.V.I.S., a calm, impeccably polite British AI butler with dry wit. " +
        "Always address the user as 'sir'. Reply in one to three short spoken sentences. " +
        "Never use markdown, lists or emojis. If you do not know something, say so plainly " +
        "and never invent facts. You run fully offline on the user's phone, so you cannot " +
        "browse the internet or know today's news."

    val VISION_PROMPT =
        "You are J.A.R.V.I.S., a polite British AI butler. The user shows you a photo. Look carefully and " +
        "answer their question in at most five short spoken sentences, plain text only, addressing them as 'sir'. " +
        "If there is text in the image, read out the important parts. If you are unsure, say so."

    val WAKE_REGEX = Regex("\\b(jarvis|jarvas|jarvus|jarves|garvis|travis|jar vis|java's)\\b")
    const val WAKE_WORD = "jarvis"

    const val PROMPT_FORMAT = "auto"      // "auto" picks by model name; or force "gemma" / "chatml"
    const val MAX_TOKENS = 1280           // only used if the model file name has no "ekvNNNN" in it
    const val HISTORY_TURNS = 4
    const val UNLOAD_BRAIN_AFTER_MINUTES = 10
    const val AWAKE_SECONDS = 8

    // ---- changeable in the app: Settings ----
    @Volatile var voiceId = 9             // 9 George, 10 Lewis (British male); 7 Emma, 8 Isabella (British female)
    @Volatile var voiceSpeed = 0.97f
    @Volatile var wakeMaxDist = 2         // 1 strict, 2 normal, 3 forgiving
    @Volatile var musicApp = "com.spotify.music"
    @Volatile var confirmCalls = true
    @Volatile var confirmTexts = true

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("jarvis_cfg", Context.MODE_PRIVATE)
        voiceId = p.getInt("voice", voiceId)
        voiceSpeed = p.getFloat("speed", voiceSpeed)
        wakeMaxDist = p.getInt("wake", wakeMaxDist)
        musicApp = p.getString("music", musicApp) ?: musicApp
        confirmCalls = p.getBoolean("confirmCalls", confirmCalls)
        confirmTexts = p.getBoolean("confirmTexts", confirmTexts)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences("jarvis_cfg", Context.MODE_PRIVATE).edit()
            .putInt("voice", voiceId)
            .putFloat("speed", voiceSpeed)
            .putInt("wake", wakeMaxDist)
            .putString("music", musicApp)
            .putBoolean("confirmCalls", confirmCalls)
            .putBoolean("confirmTexts", confirmTexts)
            .apply()
    }
}

object Wake {
    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    /** Index just after the wake word in [t], or -1 if it was not said. */
    fun find(t: String): Int {
        Config.WAKE_REGEX.find(t)?.let { return it.range.last + 1 }
        val parts = t.split(" ").filter { it.isNotEmpty() }
        val starts = ArrayList<Int>()
        var from = 0
        for (p in parts) {
            val at = t.indexOf(p, from)
            starts.add(at)
            from = at + p.length
        }
        val maxDist = Config.wakeMaxDist
        for (i in parts.indices) {
            val w = parts[i]
            if (w.length >= 4 && lev(w, Config.WAKE_WORD) <= maxDist) return starts[i] + w.length
            if (i + 1 < parts.size) {
                val j = w + parts[i + 1]
                if (j.length >= 4 && lev(j, Config.WAKE_WORD) <= maxDist) return starts[i + 1] + parts[i + 1].length
            }
        }
        return -1
    }
}
