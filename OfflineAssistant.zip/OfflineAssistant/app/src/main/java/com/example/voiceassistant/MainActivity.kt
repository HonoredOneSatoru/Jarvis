package com.example.voiceassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** One big button that always does the next thing needed. */
class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var bigButton: Button
    @Volatile private var downloading = false
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    private val perms: Array<String> by lazy {
        val l = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        l.toTypedArray()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 100, 40, 40)
        }
        statusView = TextView(this).apply { textSize = 18f }
        logView = TextView(this).apply { textSize = 16f }
        scroll = ScrollView(this).apply { addView(logView) }
        bigButton = Button(this).apply {
            textSize = 20f
            setOnClickListener { nextStep() }
        }
        val stop = Button(this).apply {
            text = "Stop Jarvis"
            setOnClickListener {
                startService(Intent(this@MainActivity, JarvisService::class.java).setAction(JarvisService.ACTION_STOP))
            }
        }
        root.addView(statusView)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bigButton, LinearLayout.LayoutParams(-1, 240))
        root.addView(stop)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        Bus.listener = { runOnUiThread { render() } }
        render()
    }

    override fun onPause() {
        Bus.listener = null
        super.onPause()
    }

    // ------------------------------------------------------------------ what is the next step?
    private fun permsDone() =
        prefs.getBoolean("asked", false) &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun label(): String = when {
        downloading -> "Downloading... keep this screen open"
        !permsDone() -> "1/4  Allow permissions"
        !Settings.canDrawOverlays(this) -> "2/4  Allow 'Display over other apps'"
        Setup.missing(this).isNotEmpty() -> "3/4  Download Jarvis (about 2.3 GB)"
        JarvisService.running -> "Jarvis is running. Tap to restart him"
        else -> "4/4  START JARVIS"
    }

    private fun render() {
        statusView.text = "Status: ${Bus.status}"
        synchronized(Bus.lines) { logView.text = Bus.lines.joinToString("\n\n") }
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        bigButton.text = label()
    }

    private fun nextStep() {
        when {
            downloading -> {}
            !permsDone() -> requestPermissions(perms, 1)
            !Settings.canDrawOverlays(this) -> {
                Toast.makeText(this, "Switch Jarvis ON, then come back and tap the button", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            Setup.missing(this).isNotEmpty() -> startDownload()
            JarvisService.running -> {
                startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_STOP))
                Handler(Looper.getMainLooper()).postDelayed({ startJarvis() }, 1500)
            }
            else -> startJarvis()
        }
        render()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        prefs.edit().putBoolean("asked", true).apply()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) nextStep()
        else {
            Toast.makeText(this, "Jarvis needs the microphone to work", Toast.LENGTH_LONG).show()
            prefs.edit().putBoolean("asked", false).apply()
            render()
        }
    }

    private fun startDownload() {
        downloading = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Bus.log("Downloading Jarvis. Keep your VPN ON for this one-time step. If it stops, tap the button again: it resumes.")
        Thread {
            var ok = false
            try {
                Setup.run(this)
                ok = true
            } catch (e: Throwable) {
                Bus.log("Download problem: ${e.message}")
                Bus.setStatus("Stopped. Check VPN / space, then tap the button again (it resumes).")
            }
            runOnUiThread {
                downloading = false
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                render()
                if (ok) nextStep()
            }
        }.start()
    }

    private fun startJarvis() {
        startForegroundService(Intent(this, JarvisService::class.java))
    }
}
