package com.example.voiceassistant

/** Tiny message board between the background service and the screen. */
object Bus {
    val lines = ArrayList<String>()
    @Volatile var status = "Stopped"
    @Volatile var listener: (() -> Unit)? = null

    fun log(line: String) {
        synchronized(lines) {
            lines.add(line)
            while (lines.size > 200) lines.removeAt(0)
        }
        listener?.invoke()
    }

    fun setStatus(s: String) {
        status = s
        listener?.invoke()
    }
}
