package com.example.voiceassistant

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.telephony.SmsManager
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Understands phone commands without needing the LLM (fast and reliable). */
object Actions {

    /** [confirm] = question to ask first (null = just do it). [run] does it and returns what Jarvis says. */
    class Act(val confirm: String?, val run: () -> String)

    /** Set by the service: lets Actions speak up later (e.g. when music did not start). */
    @Volatile var followUp: ((String) -> Unit)? = null

    private val ones = mapOf(
        "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6,
        "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12,
        "thirteen" to 13, "fourteen" to 14, "fifteen" to 15, "sixteen" to 16, "seventeen" to 17,
        "eighteen" to 18, "nineteen" to 19
    )
    private val tens = mapOf(
        "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50,
        "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
    )

    fun parse(ctx: Context, raw: String): Act? {
        val t = raw.lowercase().replace(Regex("[^a-z0-9' ]"), " ").replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty()) return null
        val tokens = t.split(" ")
        fun has(vararg w: String) = w.any { t.contains(it) }

        // ---- quick facts ----
        if (Regex("what('s| is| s)? (the )?time|what time is it|tell me the time").containsMatchIn(t))
            return Act(null) { "It is ${fmt("h:mm a")}, sir." }

        if (has("what day") || Regex("what('s| is| s)? (the )?date|today's date").containsMatchIn(t))
            return Act(null) { "Today is ${fmt("EEEE, d MMMM")}, sir." }

        if (has("battery"))
            return Act(null) {
                val bm = ctx.getSystemService(BatteryManager::class.java)
                val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                "The battery is at $lvl percent${if (bm.isCharging) " and charging" else ""}, sir."
            }

        // ---- device controls ----
        if (has("flashlight", "flash light", "torch")) {
            val off = Regex("\\boff\\b").containsMatchIn(t)
            return Act(null) { torch(ctx, !off) }
        }

        if (has("volume", "louder", "quieter", "mute")) {
            return Act(null) {
                val am = ctx.getSystemService(AudioManager::class.java)
                when {
                    has("mute") -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); "Muted, sir." }
                    has("up", "louder", "increase", "raise") -> {
                        repeat(3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
                        "Volume increased, sir."
                    }
                    else -> {
                        repeat(3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
                        "Volume lowered, sir."
                    }
                }
            }
        }

        // ---- music (works with Spotify and any media app) ----
        if (t == "pause" || Regex("^(pause|stop)( the)?( music| song| track| playback| playing)$").containsMatchIn(t))
            return Act(null) { mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE); "Paused, sir." }

        if (Regex("^(resume|continue|unpause)( the)?( music| song| track| playback)?$").containsMatchIn(t) ||
            Regex("^play( the)?( music| song| track)?$").containsMatchIn(t))
            return Act(null) { mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY); "Resuming, sir." }

        if (Regex("^(?:play )?(?:the )?(?:next|skip)(?: this| the)?(?: song| track)?$").containsMatchIn(t))
            return Act(null) { mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_NEXT); "Next track, sir." }

        if (Regex("^(?:play )?(?:the )?(?:previous|last)(?: song| track)$").containsMatchIn(t) || t == "go back a song")
            return Act(null) { mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS); "Previous track, sir." }

        Regex("^(?:play|put on|listen to)(?: me)?(?: some)? (.+)$").find(t)?.let { m ->
            var q = m.groupValues[1].trim()
            var pkg = Config.musicApp
            var appName = if (pkg == "com.spotify.music") "Spotify" else "your music app"
            Regex("^(.*?)\\s+on\\s+(spotify|youtube music|youtube)$").find(q)?.let { mm ->
                q = mm.groupValues[1].trim()
                when (mm.groupValues[2]) {
                    "spotify" -> { pkg = "com.spotify.music"; appName = "Spotify" }
                    "youtube music" -> { pkg = "com.google.android.apps.youtube.music"; appName = "YouTube Music" }
                    "youtube" -> { pkg = "com.google.android.youtube"; appName = "YouTube" }
                }
            }
            if (q.isEmpty()) return null
            val query = q
            val pack = pkg
            val name = appName
            return Act(null) { playFromSearch(ctx, pack, name, query) }
        }

        // ---- timer / alarm ----
        if (Regex("\\btimer\\b").containsMatchIn(t)) {
            val secs = parseDuration(tokens) ?: return Act(null) { "I did not catch the duration, sir." }
            return Act(null) {
                start(ctx, Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "Timer set for ${spokenDuration(secs)}, sir."
            }
        }

        if (has("alarm", "wake me")) {
            val hm = parseClock(t, tokens) ?: return Act(null) { "I did not catch the time, sir." }
            return Act(null) {
                start(ctx, Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, hm.first)
                    .putExtra(AlarmClock.EXTRA_MINUTES, hm.second)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hm.first); set(Calendar.MINUTE, hm.second) }
                "Alarm set for ${SimpleDateFormat("h:mm a", Locale.US).format(c.time)}, sir."
            }
        }

        // ---- text message ----
        Regex("^(?:send (?:a )?(?:text|message|sms) to|text|message|sms) (.+?) (?:saying that|saying|that says|and say|and tell (?:him|her|them)|telling (?:him|her|them)|to say|say) (.+)$")
            .find(t)?.let { m ->
                val who = m.groupValues[1]
                val body = m.groupValues[2].replaceFirstChar { it.uppercase() }
                val contact = findContact(ctx, who)
                    ?: return Act(null) { "I could not find $who in your contacts, sir." }
                return Act(if (Config.confirmTexts) "Shall I send ${contact.first} the message: $body, sir?" else null) {
                    try {
                        val sms = ctx.getSystemService(SmsManager::class.java)
                        sms.sendMultipartTextMessage(contact.second, null, sms.divideMessage(body), null, null)
                        "Message sent to ${contact.first}, sir."
                    } catch (e: Throwable) {
                        "I am afraid the message failed, sir."
                    }
                }
            }

        // ---- call ----
        Regex("^(?:call|phone|ring|dial) (.+)$").find(t)?.let { m ->
            val who = m.groupValues[1]
            val digits = digitsFromWords(who.split(" "))
            val contact = if (digits == null) findContact(ctx, who) else null
            if (digits == null && contact == null) return Act(null) { "I could not find $who in your contacts, sir." }
            val label = contact?.first ?: digits!!
            val number = digits ?: contact!!.second
            return Act(if (Config.confirmCalls) "Shall I call $label, sir?" else null) {
                start(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
                "Calling $label, sir."
            }
        }

        // ---- open app ----
        Regex("^(?:open|launch|start|run) (?:the )?(?:app )?(.+)$").find(t)?.let { m ->
            val q = m.groupValues[1]
            return Act(null) { openApp(ctx, q) }
        }

        return null
    }

    // ------------------------------------------------------------------ helpers

    private fun mediaKey(ctx: Context, code: Int) {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun playFromSearch(ctx: Context, pkg: String, appName: String, query: String): String {
        return try {
            val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .setPackage(pkg)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                .putExtra(SearchManager.QUERY, query)
            start(ctx, i)
            // Check a few seconds later that music really started; try the play key, then open the search.
            Thread {
                try {
                    val am = ctx.getSystemService(AudioManager::class.java)
                    Thread.sleep(6000)
                    if (!am.isMusicActive) {
                        mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY)
                        Thread.sleep(4000)
                    }
                    if (!am.isMusicActive) {
                        if (pkg == "com.spotify.music") {
                            try {
                                start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(query))).setPackage(pkg))
                            } catch (_: Throwable) {}
                        }
                        followUp?.invoke("$appName opened, sir, but the music did not start. It may need an internet connection or your VPN. I have opened the search so you can tap play.")
                    }
                } catch (_: Throwable) {}
            }.start()
            "Playing $query on $appName, sir."
        } catch (e: ActivityNotFoundException) {
            "$appName does not seem to be installed, sir."
        } catch (e: Throwable) {
            "I could not start $appName, sir."
        }
    }

    private fun fmt(p: String) = SimpleDateFormat(p, Locale.US).format(Date())

    private fun start(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun torch(ctx: Context, on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return "I could not find a flashlight, sir."
            cm.setTorchMode(id, on)
            if (on) "Flashlight on, sir." else "Flashlight off, sir."
        } catch (e: Throwable) {
            "The flashlight is not responding, sir."
        }
    }

    private fun squeeze(s: String) = s.lowercase().replace(Regex("[^a-z0-9]"), "")

    private fun openApp(ctx: Context, query: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val q = squeeze(query)
        var best: String? = null
        var bestName = ""
        var bestScore = 0
        for (a in apps) {
            val label = a.loadLabel(pm).toString()
            val l = squeeze(label)
            val score = when {
                l == q -> 3
                l.startsWith(q) || q.startsWith(l) -> 2
                l.contains(q) || q.contains(l) -> 1
                else -> 0
            }
            if (score > bestScore && l.isNotEmpty()) {
                bestScore = score; best = a.activityInfo.packageName; bestName = label
            }
        }
        if (best == null) return "I could not find an app called $query, sir."
        return try {
            val i = pm.getLaunchIntentForPackage(best)!!
            start(ctx, i)
            "Opening $bestName, sir."
        } catch (e: Throwable) {
            "I could not open $bestName, sir."
        }
    }

    private fun findContact(ctx: Context, spoken: String): Pair<String, String>? {
        val names = when (spoken.trim()) {
            "mom", "mum", "mother" -> listOf("mom", "mum", "mother")
            "dad", "father" -> listOf("dad", "father")
            else -> listOf(spoken.trim())
        }
        for (n in names) {
            try {
                val c = ctx.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$n%"), null
                ) ?: continue
                c.use {
                    val rows = ArrayList<Pair<String, String>>()
                    while (it.moveToNext()) rows.add(it.getString(0) to it.getString(1))
                    if (rows.isNotEmpty()) {
                        return rows.firstOrNull { r -> r.first.equals(n, true) } ?: rows.minByOrNull { r -> r.first.length }
                    }
                }
            } catch (e: Throwable) { /* missing permission etc. */ }
        }
        return null
    }

    private fun digitsFromWords(tokens: List<String>): String? {
        val sb = StringBuilder()
        for (w in tokens) {
            val d = ones[w]
            when {
                w == "oh" -> sb.append('0')
                d != null && d <= 9 -> sb.append(d)
                w.all { it.isDigit() } -> sb.append(w)
                else -> return null
            }
        }
        return if (sb.length >= 3) sb.toString() else null
    }

    // number words -> number. Returns (value, nextIndex)
    private fun parseNum(tokens: List<String>, start: Int): Pair<Int, Int>? {
        var i = start
        var cur = 0
        var last = 0 // 0 none, 1 ones, 2 tens, 3 hundred
        while (i < tokens.size) {
            val w = tokens[i]
            if (w == "hundred" && last == 1) { cur *= 100; last = 3; i++; continue }
            val v = w.toIntOrNull() ?: ones[w] ?: tens[w] ?: break
            val isTens = tens.containsKey(w)
            when (last) {
                0 -> {}
                2 -> if (v >= 10) break
                3 -> {}
                else -> break
            }
            cur += v
            last = if (isTens) 2 else 1
            i++
        }
        return if (i > start) cur to i else null
    }

    private fun parseDuration(tokens: List<String>): Int? {
        var total = 0
        var i = 0
        while (i < tokens.size) {
            val w = tokens[i]
            if (w == "half" && i + 2 < tokens.size && (tokens[i + 1] == "an" || tokens[i + 1] == "a") && tokens[i + 2].startsWith("hour")) {
                total += 1800; i += 3; continue
            }
            var n: Int? = null
            var j = i
            val p = parseNum(tokens, i)
            if (p != null) { n = p.first; j = p.second } else if (w == "a" || w == "an") { n = 1; j = i + 1 }
            if (n != null && j < tokens.size) {
                val u = tokens[j]
                val mult = when {
                    u.startsWith("hour") || u == "hr" || u == "hrs" -> 3600
                    u.startsWith("min") -> 60
                    u.startsWith("sec") -> 1
                    else -> 0
                }
                if (mult > 0) { total += n * mult; i = j + 1; continue }
            }
            i++
        }
        return if (total > 0) total else null
    }

    private fun spokenDuration(secs: Int): String {
        val h = secs / 3600
        val m = (secs % 3600) / 60
        val s = secs % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add("$h hour${if (h > 1) "s" else ""}")
        if (m > 0) parts.add("$m minute${if (m > 1) "s" else ""}")
        if (s > 0) parts.add("$s second${if (s > 1) "s" else ""}")
        return parts.joinToString(" and ")
    }

    /** Returns (hour24, minute) from phrases like "seven thirty", "six am", "half past eight", "quarter to nine". */
    private fun parseClock(t: String, tokens: List<String>): Pair<Int, Int>? {
        val am = Regex("\\b(a m|am|in the morning)\\b").containsMatchIn(t)
        val pm = Regex("\\b(p m|pm|in the afternoon|in the evening|tonight|at night)\\b").containsMatchIn(t)
        var hour: Int
        var minute = 0
        val idxHalf = tokens.indexOf("half")
        val idxQuarter = tokens.indexOf("quarter")
        when {
            idxHalf >= 0 && tokens.getOrNull(idxHalf + 1) == "past" -> {
                hour = parseNum(tokens, idxHalf + 2)?.first ?: return null; minute = 30
            }
            idxQuarter >= 0 && tokens.getOrNull(idxQuarter + 1) == "past" -> {
                hour = parseNum(tokens, idxQuarter + 2)?.first ?: return null; minute = 15
            }
            idxQuarter >= 0 && tokens.getOrNull(idxQuarter + 1) == "to" -> {
                hour = (parseNum(tokens, idxQuarter + 2)?.first ?: return null) - 1; minute = 45
            }
            else -> {
                var found: Pair<Int, Int>? = null
                var i = 0
                while (i < tokens.size && found == null) { found = parseNum(tokens, i); if (found == null) i++ }
                val f = found ?: return null
                hour = f.first
                var next = f.second
                if (hour >= 100) { minute = hour % 100; hour /= 100 }
                else {
                    if (tokens.getOrNull(next) == "oh" || tokens.getOrNull(next) == "o") next++
                    val mm = parseNum(tokens, next)
                    if (mm != null && mm.first < 60) minute = mm.first
                }
            }
        }
        if (hour < 0 || hour > 24 || minute > 59) return null
        if (hour == 24) hour = 0
        when {
            am -> if (hour == 12) hour = 0
            pm -> if (hour < 12) hour += 12
            hour in 1..12 -> {
                // no am/pm said: choose the next time that will happen
                val now = Calendar.getInstance()
                val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                val a = (hour % 12) * 60 + minute
                val b = a + 720
                fun waitMin(x: Int) = ((x - nowMin) + 1440) % 1440
                hour = (if (waitMin(a) <= waitMin(b)) a else b) / 60
            }
        }
        return hour to minute
    }
}
