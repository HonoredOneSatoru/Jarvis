package com.example.voiceassistant

/** Tiny message board between the background service and the screen. */
object Bus {
    val lines = ArrayList<String>()
    @Volatile var statusText = "Stopped"
    @Volatile var listener: (() -> Unit)? = null

    fun log(line: String) {
        synchronized(lines) {
            lines.add(line)
            while (lines.size > 200) lines.removeAt(0)
        }
        listener?.invoke()
    }

    fun setStatus(s: String) {
        statusText = s
        listener?.invoke()
    }
}
