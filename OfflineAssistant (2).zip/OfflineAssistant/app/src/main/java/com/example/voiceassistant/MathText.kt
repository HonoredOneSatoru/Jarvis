package com.example.voiceassistant

/** Turns the AI's maths (which may contain LaTeX like $\frac{1}{2}$) into readable text, and into words for the voice. */
object MathText {
    private val fracRe = Regex("\\\\d?frac\\s*\\{([^{}]*)\\}\\s*\\{([^{}]*)\\}")
    private val sqrtRe = Regex("\\\\sqrt\\s*\\{([^{}]*)\\}")
    private val textRe = Regex("\\\\(?:text|mathrm|mathbf|operatorname)\\s*\\{([^{}]*)\\}")
    private val supRe = Regex("\\^\\{([^{}]*)\\}")
    private val subRe = Regex("_\\{([^{}]*)\\}")

    private val commands = linkedMapOf(
        "\\left" to "", "\\right" to "",
        "\\times" to "×", "\\cdot" to "·", "\\div" to "÷", "\\pm" to "±",
        "\\leq" to "≤", "\\le" to "≤", "\\geq" to "≥", "\\ge" to "≥", "\\neq" to "≠", "\\approx" to "≈",
        "\\pi" to "π", "\\infty" to "∞", "\\rightarrow" to "→", "\\to" to "→",
        "\\," to " ", "\\;" to " ", "\\!" to "", "\\ " to " ", "\\%" to "%"
    )

    private fun wrap(x: String): String = if (Regex("[A-Za-z0-9.]+").matches(x.trim())) x.trim() else "(${x.trim()})"

    private fun sup(x: String): String = when (x.trim()) {
        "2" -> "²"
        "3" -> "³"
        else -> "^" + x.trim()
    }

    /** Readable maths for the screen: no $ signs, no backslashes. */
    fun toDisplay(input: String): String {
        var t = input
        t = t.replace("\\(", "").replace("\\)", "").replace("\\[", "").replace("\\]", "")
        t = t.replace("$$", "").replace("$", "")
        repeat(3) {
            t = fracRe.replace(t) { m -> wrap(m.groupValues[1]) + "/" + wrap(m.groupValues[2]) }
            t = sqrtRe.replace(t) { m -> "√" + wrap(m.groupValues[1]) }
            t = textRe.replace(t) { m -> m.groupValues[1] }
            t = supRe.replace(t) { m -> sup(m.groupValues[1]) }
            t = subRe.replace(t) { m -> m.groupValues[1] }
        }
        for ((k, v) in commands) t = t.replace(k, v)
        t = Regex("\\\\[a-zA-Z]+").replace(t, "")
        t = t.replace("{", "").replace("}", "")
        t = t.replace("^2", "²").replace("^3", "³")
        // light markdown clean-up
        t = t.replace("**", "").replace("__", "").replace("`", "").replace("_", "")
        t = Regex("(?m)^\\s*#+\\s*").replace(t, "")
        t = Regex("(?m)^\\s*>\\s?").replace(t, "")
        t = Regex("(?m)^\\s*\\*\\s+").replace(t, "• ")
        t = Regex("(?<=[0-9A-Za-z)])\\s*\\*\\s*(?=[0-9A-Za-z(])").replace(t, "×")
        return t.trim()
    }

    private val common = mapOf(
        "1/2" to "one half", "1/3" to "one third", "2/3" to "two thirds", "1/4" to "one quarter",
        "3/4" to "three quarters", "1/5" to "one fifth", "1/10" to "one tenth"
    )

    /** Maths written out as words, so the voice reads it properly. */
    fun toSpeech(display: String): String {
        var t = display
        t = t.replace("²", " squared ").replace("³", " cubed ")
        t = Regex("√\\s*\\(?([^\\s)]+)\\)?").replace(t) { m -> " square root of ${m.groupValues[1]} " }
        t = t.replace("×", " times ").replace("·", " times ").replace("÷", " divided by ")
        t = t.replace("±", " plus or minus ").replace("≤", " is less than or equal to ")
        t = t.replace("≥", " is greater than or equal to ").replace("≠", " is not equal to ")
        t = t.replace("≈", " is approximately ").replace("π", " pi ").replace("∞", " infinity ").replace("→", " goes to ")
        t = Regex("(?<![0-9.])(\\d+)/(\\d+)(?![0-9])").replace(t) { m ->
            common[m.groupValues[1] + "/" + m.groupValues[2]] ?: "${m.groupValues[1]} over ${m.groupValues[2]}"
        }
        t = Regex("(?<=[0-9)])/(?=[0-9A-Za-z(])").replace(t, " over ")
        t = Regex("(?<=[A-Za-z])/(?=[0-9])").replace(t, " over ")
        t = t.replace("%", " percent")
        t = Regex("(?<=[0-9A-Za-z)])\\s*[−–]\\s*(?=[0-9A-Za-z(])").replace(t, " minus ")
        t = t.replace(" - ", " minus ")
        t = Regex("(?<=[0-9)])-(?=[0-9A-Za-z(])").replace(t, " minus ")
        t = Regex("(?<=[A-Za-z])-(?=[0-9])").replace(t, " minus ")
        t = t.replace("=", " equals ").replace("+", " plus ").replace("*", " times ").replace("^", " to the power of ")
        t = t.replace("<", " is less than ").replace(">", " is greater than ")
        return t.replace(Regex("\\s+"), " ").trim()
    }
}
