package com.example.voiceassistant

import java.util.Locale

/** Exact, instant answers for plain arithmetic ("what is twelve times seven", "15 percent of 240", "(3+4)*5"). */
object Calc {

    fun answer(raw: String): String? {
        var s = raw.lowercase().trim()
        // teaching requests go to the AI, which explains step by step
        if (Regex("\\b(step|explain|teach|how do|how to|why|solve for|equation|derivative|integral|prove|fraction|simplify|factor)\\b").containsMatchIn(s)) return null
        s = s.replace(Regex("^((hey|ok|okay|please|can you|could you|jarvis|neko|nico|niko) )+"), "")
        s = s.replace(Regex("^(what is|what's|whats|how much is|calculate|compute|evaluate|work out|tell me|find|solve) +"), "")
        s = s.replace(Regex("[?,=]"), " ").replace(Regex("\\s+"), " ").trim()
        if (s.isEmpty()) return null

        // number words -> digits
        val tokens = s.split(" ")
        val out = ArrayList<String>()
        var i = 0
        while (i < tokens.size) {
            val p = Actions.parseNum(tokens, i)
            if (p != null) { out.add(p.first.toString()); i = p.second } else { out.add(tokens[i]); i++ }
        }
        var e = " " + out.joinToString(" ") + " "
        e = e.replace(" multiplied by ", " * ").replace(" times ", " * ")
            .replace(" divided by ", " / ").replace(" over ", " / ")
            .replace(" plus ", " + ").replace(" minus ", " - ")
            .replace(" to the power of ", " ^ ")
            .replace(" squared ", "^2 ").replace(" cubed ", "^3 ")
            .replace("×", "*").replace("÷", "/")
        e = Regex("(?<=\\d) x (?=\\d)").replace(e, " * ")
        e = Regex("(\\d+(?:\\.\\d+)?) ?(?:percent|%) of ").replace(e) { m -> "(${m.groupValues[1]}/100)*" }
        e = Regex("square root of (\\d+(?:\\.\\d+)?)").replace(e) { m -> "sqrt(${m.groupValues[1]})" }
        e = e.trim()

        if (!Regex("[0-9+\\-*/^().sqrt ]+").matches(e)) return null
        if (!Regex("[+\\-*/^]|sqrt").containsMatchIn(e)) return null
        val v = try { Parser(e).parse() } catch (_: Exception) { return null }
        if (v.isNaN() || v.isInfinite()) return "That is not possible, ${Config.addr}. You cannot divide by zero."
        val txt = if (v == Math.rint(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else String.format(Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')
        return "That is $txt, ${Config.addr}."
    }

    private class Parser(private val s: String) {
        private var i = 0

        private fun ws() { while (i < s.length && s[i] == ' ') i++ }
        private fun peek(): Char { ws(); return if (i < s.length) s[i] else '\u0000' }

        fun parse(): Double {
            val v = expr()
            ws()
            if (i != s.length) throw IllegalArgumentException("extra input")
            return v
        }

        private fun expr(): Double {
            var v = term()
            while (true) {
                val c = peek()
                if (c == '+') { i++; v += term() } else if (c == '-') { i++; v -= term() } else return v
            }
        }

        private fun term(): Double {
            var v = power()
            while (true) {
                val c = peek()
                if (c == '*') { i++; v *= power() } else if (c == '/') { i++; v /= power() } else return v
            }
        }

        private fun power(): Double {
            val b = unary()
            if (peek() == '^') { i++; return Math.pow(b, power()) }
            return b
        }

        private fun unary(): Double {
            val c = peek()
            if (c == '-') { i++; return -unary() }
            if (c == '+') { i++; return unary() }
            return atom()
        }

        private fun atom(): Double {
            ws()
            if (s.startsWith("sqrt", i)) {
                i += 4
                if (peek() != '(') throw IllegalArgumentException("sqrt needs (")
                i++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("missing )")
                i++
                return Math.sqrt(v)
            }
            if (peek() == '(') {
                i++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("missing )")
                i++
                return v
            }
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (start == i) throw IllegalArgumentException("number expected")
            return s.substring(start, i).toDouble()
        }
    }
}
