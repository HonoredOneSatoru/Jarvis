package com.example.voiceassistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/** Chat-style home screen. One big button always does the next thing that is needed. */
class MainActivity : Activity() {

    private val PICK_BRAIN = 42
    private val PICK_PHOTO = 43

    private val cBg = Color.parseColor("#0D1117")
    private val cCard = Color.parseColor("#161B22")
    private val cText = Color.parseColor("#E6EDF3")
    private val cMuted = Color.parseColor("#8B949E")
    private val cAccent = Color.parseColor("#2F81F7")
    private val cGreen = Color.parseColor("#2EA043")
    private val cRed = Color.parseColor("#F85149")
    private val cOrange = Color.parseColor("#D29922")
    private val cGray = Color.parseColor("#484F58")

    private lateinit var statusPill: TextView
    private lateinit var statusLine: TextView
    private lateinit var setupCard: LinearLayout
    private lateinit var checkRows: LinearLayout
    private lateinit var bigButton: Button
    private lateinit var scroll: ScrollView
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var titleView: TextView
    private lateinit var hintView: TextView

    private val downloading: Boolean get() = Setup.busy.get()
    private var shown = 0
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    private val perms: Array<String> by lazy {
        val l = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        l.toTypedArray()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int = 14) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    // ================================================================== UI
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Config.load(this)
        actionBar?.hide()
        window.setBackgroundDrawable(ColorDrawable(cBg))
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
        }
        root.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(dp(16), insets.systemWindowInsetTop + dp(8), dp(16), insets.systemWindowInsetBottom + dp(8))
            insets
        }

        // ---- header ----
        titleView = TextView(this).apply {
            text = "NEKO"
            textSize = 22f
            setTextColor(cText)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
        }
        statusPill = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(5), dp(12), dp(5))
        }
        val menu = TextView(this).apply {
            text = "⋮"
            textSize = 26f
            setTextColor(cText)
            setPadding(dp(14), 0, dp(4), 0)
            setOnClickListener { showMenu(it) }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(titleView, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(statusPill)
            addView(menu)
        }
        statusLine = TextView(this).apply {
            textSize = 12f
            setTextColor(cMuted)
            setPadding(0, dp(6), 0, dp(8))
        }

        // ---- setup card ----
        setupCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(cCard)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val setupTitle = TextView(this).apply {
            text = "Getting ready"
            textSize = 15f
            setTextColor(cText)
            typeface = Typeface.DEFAULT_BOLD
        }
        checkRows = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, 0)
        }
        bigButton = Button(this).apply {
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = round(cAccent)
            setOnClickListener { nextStep() }
        }
        setupCard.addView(setupTitle)
        setupCard.addView(checkRows)
        setupCard.addView(bigButton, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })

        // ---- conversation ----
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(chat)
        }
        hintView = TextView(this).apply {
            text = hintText()
            textSize = 13f
            setTextColor(cMuted)
            background = round(cCard)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        chat.addView(hintView)

        // ---- quick chips ----
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(4))
        }
        listOf(
            "What time is it" to "what time is it",
            "Tell me a joke" to "tell me a joke",
            "Maths help" to "solve two x plus three equals eleven step by step",
            "Battery" to "battery level",
            "Flashlight" to "flashlight on",
            "Open Spotify" to "open spotify",
            "Pause" to "pause",
            "Next song" to "next song"
        ).forEach { (label, cmd) ->
            chips.addView(chip(label) { svc(JarvisService.ACTION_TEXT, cmd) },
                LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        val chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chips)
        }

        // ---- input row ----
        input = EditText(this).apply {
            hint = "Type a command…"
            setHintTextColor(cMuted)
            setTextColor(cText)
            textSize = 15f
            setSingleLine(true)
            background = round(cCard, 24)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> submit(); true }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, 0)
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(roundBtn("📷", cGray) { pickPhoto() })
            addView(roundBtn("➤", cAccent) { submit() })
            addView(roundBtn("🎙", cGreen) { svc(JarvisService.ACTION_WAKE, null) })
        }

        root.addView(header)
        root.addView(statusLine)
        root.addView(setupCard)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(chipScroll)
        root.addView(row)
        setContentView(root)
    }

    private fun hintText() =
        "Say “Hey ${Config.name}”, then try:\n" +
            "•  solve 2x plus 3 equals 11  (maths, step by step)\n" +
            "•  play Blinding Lights on Spotify\n" +
            "•  open WhatsApp  /  set a timer for ten minutes\n" +
            "•  call Mom  /  tell me a joke\n" +
            "Tap the camera to ask about a photo, or type below."

    private fun chip(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(cText)
        background = round(cCard, 20)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { onClick() }
    }

    private fun roundBtn(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
        this.text = label
        textSize = 18f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = round(color, 24)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { leftMargin = dp(8) }
    }

    override fun onResume() {
        super.onResume()
        Bus.listener = { runOnUiThread { render() } }
        render()
        maybeOfferBetterEars()
    }

    override fun onPause() {
        Bus.listener = null
        super.onPause()
    }

    // ================================================================== state -> screen
    private fun permsDone() =
        prefs.getBoolean("asked", false) &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun ready() = permsDone() && Settings.canDrawOverlays(this) && Setup.missing(this).isEmpty()

    private fun label(): String = when {
        downloading -> "Working… (you can leave the app)"
        !permsDone() -> "1/4  Allow permissions"
        !Settings.canDrawOverlays(this) -> "2/4  Allow “Display over other apps”"
        Setup.missing(this).isNotEmpty() -> "3/4  Download (about 3 GB)"
        JarvisService.running -> "Restart"
        else -> "4/4  START"
    }

    private fun pill(): Pair<String, Int> {
        val s = Bus.statusText
        return when {
            downloading -> "Working" to cOrange
            !ready() -> "Setup needed" to cOrange
            !JarvisService.running -> "Stopped" to cGray
            s.contains("Working") -> "Thinking" to cAccent
            s.contains("Yes, sir") -> "Awake" to cAccent
            s.startsWith("Listening") -> "Listening" to cGreen
            else -> s.take(16) to cAccent
        }
    }

    private fun render() {
        val (txt, col) = pill()
        statusPill.text = txt
        statusPill.background = round(col, 20)
        statusLine.text = Bus.statusText
        titleView.text = Config.name.uppercase()
        hintView.text = hintText()

        setupCard.visibility = if (ready() && JarvisService.running) View.GONE else View.VISIBLE
        buildChecks()
        bigButton.text = label()
        drawNewMessages()
    }

    private fun buildChecks() {
        checkRows.removeAllViews()
        fun row(ok: Boolean, name: String, detail: String? = null) {
            checkRows.addView(TextView(this).apply {
                this.text = (if (ok) "✔  " else "✖  ") + name + (if (detail != null) "\n      $detail" else "")
                textSize = 14f
                setTextColor(if (ok) cGreen else cRed)
                setPadding(0, dp(3), 0, dp(3))
            })
        }
        row(permsDone(), "Permissions")
        row(Settings.canDrawOverlays(this), "Display over other apps (timers, apps)")
        row(File(Setup.voskDir(this), "am").isDirectory, "Ears: speech recognition")
        row(File(Setup.kokoroDir(this), "model.onnx").exists(), "Voice: British butler")
        val b = Setup.brainFile(this)
        when {
            b != null && Bus.brainError == null ->
                row(true, "Brain: offline AI", "${b.name.removeSuffix(".litertlm")} · ${b.length() / 1_000_000} MB")
            b != null -> row(false, "Brain needs repair", "Menu ⋮ → Repair brain")
            else -> row(false, "Brain: offline AI (not downloaded)")
        }
        val na = Actions.hasNotificationAccess(this)
        checkRows.addView(TextView(this).apply {
            this.text = (if (na) "✔  " else "○  ") + "Precise music control (optional)" +
                (if (na) "" else "\n      Menu ⋮ → Settings → Precise music control")
            textSize = 13f
            setTextColor(if (na) cGreen else cMuted)
            setPadding(0, dp(3), 0, dp(3))
        })
    }

    private fun drawNewMessages() {
        var snapshot: List<String> = emptyList()
        var total = 0
        synchronized(Bus.lines) {
            snapshot = ArrayList(Bus.lines)
            total = Bus.total
        }
        val newCount = total - shown
        if (newCount <= 0) return
        val fresh = if (newCount >= snapshot.size) snapshot else snapshot.takeLast(newCount)
        for (l in fresh) addBubble(l)
        shown = total
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addBubble(line: String) {
        val kind: Int
        val msg: String
        when {
            line.startsWith("You: ") -> { kind = 0; msg = line.removePrefix("You: ") }
            line.startsWith("Jarvis: ") -> { kind = 1; msg = line.removePrefix("Jarvis: ") }
            line.startsWith("heard: ") -> { kind = 2; msg = "🎧 " + line.removePrefix("heard: ") }
            else -> { kind = 3; msg = line }
        }
        val low = msg.lowercase()
        val bad = kind == 3 && (low.contains("error") || low.contains("problem") || low.contains("failed") ||
            low.contains("damaged") || low.contains("stopped"))
        val tv = TextView(this).apply {
            this.text = msg
            when (kind) {
                0 -> { textSize = 15f; setTextColor(Color.WHITE); background = round(cAccent, 18); setPadding(dp(14), dp(9), dp(14), dp(9)) }
                1 -> { textSize = 15f; setTextColor(cText); background = round(cCard, 18); setPadding(dp(14), dp(9), dp(14), dp(9)) }
                2 -> { textSize = 11f; setTextColor(cMuted) }
                else -> { textSize = 12f; setTextColor(if (bad) cRed else cMuted); gravity = Gravity.CENTER }
            }
            maxWidth = (resources.displayMetrics.widthPixels * 0.82).toInt()
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(if (kind == 2) 2 else 8)
        lp.gravity = when (kind) {
            0 -> Gravity.END
            1, 2 -> Gravity.START
            else -> Gravity.CENTER_HORIZONTAL
        }
        chat.addView(tv, lp)
        while (chat.childCount > 300) chat.removeViewAt(1)
    }

    // ================================================================== the one big button
    private fun nextStep() {
        when {
            downloading -> {}
            !permsDone() -> requestPermissions(perms, 1)
            !Settings.canDrawOverlays(this) -> {
                Toast.makeText(this, "Switch the app ON, then come back and tap the button", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            Setup.missing(this).isNotEmpty() -> startDownload()
            JarvisService.running -> {
                stopJarvis()
                Handler(Looper.getMainLooper()).postDelayed({ startJarvis() }, 1500)
            }
            else -> startJarvis()
        }
        render()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        prefs.edit().putBoolean("asked", true).apply()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) nextStep()
        else {
            Toast.makeText(this, "The app needs the microphone to work", Toast.LENGTH_LONG).show()
            prefs.edit().putBoolean("asked", false).apply()
            render()
        }
    }

    private fun startJarvis() {
        startForegroundService(Intent(this, JarvisService::class.java))
    }

    private fun stopJarvis() {
        startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_STOP))
    }

    /** Sends a test command / action to the running service. */
    private fun svc(action: String, extra: String?) {
        if (!JarvisService.running) {
            Toast.makeText(this, "Start first (big button)", Toast.LENGTH_SHORT).show()
            return
        }
        startService(Intent(this, JarvisService::class.java).setAction(action).apply {
            if (extra != null) putExtra("text", extra)
        })
    }

    private fun submit() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        svc(JarvisService.ACTION_TEXT, t)
        input.setText("")
    }

    // ================================================================== long jobs
    /** Runs [work] on a background thread with the screen kept awake; failures show in the chat. */
    private fun runBusy(work: () -> Unit, after: (Boolean) -> Unit = {}) {
        if (!Setup.busy.compareAndSet(false, true)) return
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        render()
        Thread {
            var ok = false
            try {
                work()
                ok = true
            } catch (e: Throwable) {
                Bus.log("Problem: ${e.message}")
                Bus.setStatus("Stopped. Read the message above, then tap the button to try again (it resumes).")
            }
            runOnUiThread {
                Setup.busy.set(false)
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                render()
                after(ok)
            }
        }.start()
    }

    private fun startDownload() {
        Bus.log("Downloading (about 3 GB: ears, voice and a Gemma 4 brain that can also see photos). Keep your VPN on. You can leave the app: a notification shows progress, and it resumes by itself if the connection drops.")
        startForegroundService(Intent(this, SetupService::class.java).setAction(SetupService.ACTION_INSTALL))
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_BRAIN && resultCode == RESULT_OK) data?.data?.let { importBrain(it) }
        if (requestCode == PICK_PHOTO && resultCode == RESULT_OK) data?.data?.let { askAboutPhoto(it) }
    }

    /** Copies a brain file (.litertlm) that the person downloaded with the phone browser. */
    private fun importBrain(uri: Uri) {
        runBusy({
            var name = "brain.litertlm"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = c.getString(i) ?: name
                }
            }
            if (!name.endsWith(".litertlm")) {
                throw IOException("please pick the .litertlm brain file (you picked $name)")
            }
            val dest = File(Setup.baseDir(this), name)
            val part = File(dest.path + ".part")
            var copied = 0L
            contentResolver.openInputStream(uri)!!.use { input ->
                FileOutputStream(part).use { out ->
                    val buf = ByteArray(256 * 1024)
                    var last = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        copied += n
                        val now = System.currentTimeMillis()
                        if (now - last > 700) { last = now; Bus.setStatus("Importing brain: ${copied / 1_000_000} MB") }
                    }
                }
            }
            dest.delete()
            if (!part.renameTo(dest)) throw IOException("could not save the file")
            if (!Setup.isValidBrain(dest)) {
                dest.delete()
                throw IOException("that file is incomplete or damaged (the browser download was cut short). Download it again.")
            }
            Bus.brainError = null
            Bus.log("Brain imported: $name (${copied / 1_000_000} MB)")
            Bus.setStatus("Brain imported.")
        })
    }

    private fun repairBrain() {
        AlertDialog.Builder(this)
            .setTitle("Repair brain")
            .setMessage("This deletes the current brain file and downloads a fresh, verified one (about 1.6 GB). Continue?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Repair") { _, _ ->
                stopJarvis()
                Setup.resetBrain(this)
                Bus.log("Brain removed. Downloading a fresh one…")
                Handler(Looper.getMainLooper()).postDelayed({ nextStep() }, 800)
            }
            .show()
    }

    private fun startEarsUpgrade() {
        stopJarvis()
        Bus.log("Downloading better ears (about 130 MB)…")
        startForegroundService(Intent(this, SetupService::class.java).setAction(SetupService.ACTION_EARS))
    }

    private fun upgradeEars() {
        AlertDialog.Builder(this)
            .setTitle("Better speech recognition")
            .setMessage("Downloads a larger speech model (about 130 MB) so it understands you more accurately. It restarts afterwards.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Download") { _, _ -> startEarsUpgrade() }
            .show()
    }

    /** Asked once, if the small speech model is still installed. */
    private fun maybeOfferBetterEars() {
        if (prefs.getBoolean("ears_prompted", false) || !ready() || downloading) return
        prefs.edit().putBoolean("ears_prompted", true).apply()
        if (Setup.hasBetterEars(this)) return
        AlertDialog.Builder(this)
            .setTitle("Better hearing?")
            .setMessage("Download a more accurate speech model (about 130 MB) so ${Config.name} understands you better. Recommended.")
            .setNegativeButton("Later", null)
            .setPositiveButton("Download") { _, _ -> startEarsUpgrade() }
            .show()
    }

    private fun upgradeBrain() {
        AlertDialog.Builder(this)
            .setTitle("Smarter brain")
            .setMessage("Downloads Gemma 4 E4B (about 3.7 GB): a bigger brain that is better at maths and reasoning, and a little slower. You need about 5 GB free. Keep your VPN on. If it does not work, the current brain is used again.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Download") { _, _ ->
                stopJarvis()
                Bus.log("Downloading the bigger brain (about 3.7 GB). You can leave the app.")
                startForegroundService(Intent(this, SetupService::class.java).setAction(SetupService.ACTION_BIG_BRAIN))
            }
            .show()
    }

    // ================================================================== menu, settings, help
    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "Settings")
        m.menu.add(0, 2, 1, "Test voice")
        m.menu.add(0, 3, 2, "Wake now")
        m.menu.add(0, 4, 3, "What can I say?")
        m.menu.add(0, 5, 4, "Better speech recognition (+130 MB)")
        m.menu.add(0, 6, 5, "Import brain file…")
        m.menu.add(0, 7, 6, "Repair brain (download fresh)")
        m.menu.add(0, 8, 7, "Copy report for support")
        m.menu.add(0, 10, 7, "Test brain")
        m.menu.add(0, 11, 2, "Ask about a photo…")
        m.menu.add(0, 12, 6, "Smarter brain (+3.7 GB)")
        m.menu.add(0, 9, 8, "Stop")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> showSettings()
                2 -> svc(JarvisService.ACTION_TEST_VOICE, null)
                3 -> svc(JarvisService.ACTION_WAKE, null)
                4 -> showHelp()
                5 -> upgradeEars()
                6 -> {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(i, PICK_BRAIN)
                }
                7 -> repairBrain()
                8 -> copyReport()
                9 -> stopJarvis()
                10 -> svc(JarvisService.ACTION_TEST_BRAIN, null)
                11 -> pickPhoto()
                12 -> upgradeBrain()
            }
            true
        }
        m.show()
    }

    private fun showHelp() {
        AlertDialog.Builder(this)
            .setTitle("What can I say?")
            .setMessage(
                "Start with “Hey ${Config.name}”, wait for “Yes, ${Config.addr}?”, then:\n\n" +
                    "TIMERS: set a timer for ten minutes\n" +
                    "ALARMS: set an alarm for seven thirty a m\n" +
                    "APPS: open WhatsApp\n" +
                    "MUSIC: play Blinding Lights · open Spotify and play Numb · pause · next song\n" +
                    "WEB: search for pizza near me · navigate to the airport\n" +
                    "CALLS: call Mom (he asks first)\n" +
                    "TEXTS: text John saying I will be late\n" +
                    "PHONE: flashlight on/off · volume up/down · mute · battery level\n" +
                    "FACTS: what time is it · what is the date\n" +
                    "MATHS: solve 2x plus 3 equals 11 · what is twelve times seven · explain fractions step by step\n" +
                    "ANYTHING ELSE: jokes, questions, advice (offline brain)"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showSettings() {
        val personas = listOf("Neko: cheerful anime girl" to "neko", "Jarvis: British butler" to "jarvis")
        val voices = listOf(
            "Sky (American girl, bright)" to 4, "Bella (American girl, soft)" to 1,
            "Emma (British girl)" to 7, "Isabella (British girl)" to 8,
            "George (British man)" to 9, "Lewis (British man)" to 10,
            "Adam (American man)" to 5, "Michael (American man)" to 6
        )
        val pitches = listOf("Natural (1.00)" to 1.0f, "Cute (1.10)" to 1.10f, "Anime (1.18)" to 1.18f, "Very high (1.28)" to 1.28f)
        val speeds = listOf("Slower (0.90)" to 0.90f, "Calm (0.97)" to 0.97f, "Normal (1.00)" to 1.0f, "Faster (1.10)" to 1.1f)
        val wakes = listOf("Strict (fewer false wake-ups)" to 1, "Normal" to 2, "Forgiving (wakes easily)" to 3)
        val musics = listOf("Spotify" to "com.spotify.music", "YouTube Music" to "com.google.android.apps.youtube.music")
        fun yn(b: Boolean) = if (b) "on" else "off"
        fun nearest(v: Float, l: List<Pair<String, Float>>) = l.minByOrNull { Math.abs(it.second - v) }!!.first

        val items = arrayOf(
            "Character: " + (personas.firstOrNull { it.second == Config.persona }?.first ?: "custom"),
            "Voice: " + (voices.firstOrNull { it.second == Config.voiceId }?.first ?: "custom"),
            "Voice pitch: " + nearest(Config.voicePitch, pitches),
            "Speaking speed: " + nearest(Config.voiceSpeed, speeds),
            "Wake word: " + wakes.first { it.second == Config.wakeMaxDist.coerceIn(1, 3) }.first,
            "Music app: " + (musics.firstOrNull { it.second == Config.musicApp }?.first ?: "custom"),
            "Ask before calling: " + yn(Config.confirmCalls),
            "Ask before texting: " + yn(Config.confirmTexts),
            "Precise music control: " + (if (Actions.hasNotificationAccess(this)) "on" else "off (tap to set up)")
        )
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> AlertDialog.Builder(this).setTitle("Character")
                        .setItems(personas.map { it.first }.toTypedArray()) { _, i ->
                            Config.applyPersona(personas[i].second); Config.save(this); render()
                            svc(JarvisService.ACTION_TEST_VOICE, null); showSettings()
                        }.show()
                    1 -> AlertDialog.Builder(this).setTitle("Voice")
                        .setItems(voices.map { it.first }.toTypedArray()) { _, i ->
                            Config.voiceId = voices[i].second; Config.save(this)
                            svc(JarvisService.ACTION_TEST_VOICE, null); showSettings()
                        }.show()
                    2 -> AlertDialog.Builder(this).setTitle("Voice pitch")
                        .setItems(pitches.map { it.first }.toTypedArray()) { _, i ->
                            Config.voicePitch = pitches[i].second; Config.save(this)
                            svc(JarvisService.ACTION_TEST_VOICE, null); showSettings()
                        }.show()
                    3 -> AlertDialog.Builder(this).setTitle("Speaking speed")
                        .setItems(speeds.map { it.first }.toTypedArray()) { _, i ->
                            Config.voiceSpeed = speeds[i].second; Config.save(this)
                            svc(JarvisService.ACTION_TEST_VOICE, null); showSettings()
                        }.show()
                    4 -> AlertDialog.Builder(this).setTitle("Wake word sensitivity")
                        .setItems(wakes.map { it.first }.toTypedArray()) { _, i ->
                            Config.wakeMaxDist = wakes[i].second; Config.save(this); showSettings()
                        }.show()
                    5 -> AlertDialog.Builder(this).setTitle("Music app")
                        .setItems(musics.map { it.first }.toTypedArray()) { _, i ->
                            Config.musicApp = musics[i].second; Config.save(this); showSettings()
                        }.show()
                    6 -> { Config.confirmCalls = !Config.confirmCalls; Config.save(this); showSettings() }
                    7 -> { Config.confirmTexts = !Config.confirmTexts; Config.save(this); showSettings() }
                    8 -> musicAccessHelp()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun musicAccessHelp() {
        AlertDialog.Builder(this)
            .setTitle("Precise music control")
            .setMessage(
                "This lets ${Config.name} tell Spotify exactly which song to play.\n\n" +
                    "1. Tap “App settings”, then ⋮ (top right) → “Allow restricted settings”.\n" +
                    "2. Come back and tap “Notification access”, then switch the app ON.\n\n" +
                    "Nothing is read from your notifications; it only lets the app see the music player."
            )
            .setPositiveButton("Notification access") { _, _ ->
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            .setNeutralButton("App settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun copyReport() {
        val sb = StringBuilder()
        sb.append("Jarvis report\n")
        sb.append("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}\n")
        val base = Setup.baseDir(this)
        sb.append("Free space: ${base.usableSpace / 1_000_000} MB\n")
        base.listFiles()?.forEach { sb.append("File: ${it.name}  ${if (it.isFile) it.length() / 1_000_000 else -1} MB\n") }
        sb.append("Valid brain: ${Setup.brainFile(this)?.name}\n")
        sb.append("Bad brains: ${Setup.badBrains(this)}\n")
        sb.append("Brain error: ${Bus.brainError}\n")
        sb.append("Status: ${Bus.statusText}\n")
        sb.append("--- last messages ---\n")
        synchronized(Bus.lines) { Bus.lines.takeLast(40).forEach { sb.append(it).append('\n') } }
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("Jarvis report", sb.toString()))
        Toast.makeText(this, "Report copied. Paste it into your message.", Toast.LENGTH_LONG).show()
    }
}
