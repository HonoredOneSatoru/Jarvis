plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.voiceassistant"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.voiceassistant"
        minSdk = 31
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
        ndk { abiFilters += "arm64-v8a" }   // S26 Ultra is arm64 only
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    packaging {
        resources {
            excludes += listOf("META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES", "META-INF/INDEX.LIST", "META-INF/*.md")
        }
        jniLibs {
            pickFirsts += listOf("**/libc++_shared.so", "**/libjnidispatch.so")
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        // the AI library may be built with a newer Kotlin than ours; this lets us read it anyway
        freeCompilerArgs.add("-Xskip-metadata-version-check")
    }
}

// Some libraries declare a newer minimum SDK / Gradle-plugin version than ours. That check only warns, so skip it.
tasks.matching { it.name.contains("AarMetadata") }.configureEach { enabled = false }

dependencies {
    // Ears (offline speech-to-text)
    implementation("com.alphacephei:vosk-android:0.3.47")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    // Voice engine. The build downloads this file into app/libs automatically (see .github/workflows/build.yml)
    implementation(files("libs/sherpa-onnx.aar"))
    // Brain: Google's LiteRT-LM (runs Gemma 4 offline, text AND images)
    implementation("com.google.ai.edge.litertlm:litertlm-android:latest.release")
    // Unpacks the voice download (.tar.bz2)
    implementation("org.apache.commons:commons-compress:1.26.2")
}
