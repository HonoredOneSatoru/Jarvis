package com.example.voiceassistant

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** The offline LLM. Loaded on first use and unloaded when idle to give RAM back. */
class Brain(private val ctx: Context, private val modelFile: File) {
    private var llm: LlmInference? = null
    private val nameLower = modelFile.name.lowercase()
    // The context size is written in the file name (ekv4096). It must match what we ask for.
    private val maxTokens = Regex("ekv(\\d+)").find(nameLower)?.groupValues?.get(1)?.toIntOrNull() ?: Config.MAX_TOKENS
    private val format = when {
        Config.PROMPT_FORMAT != "auto" -> Config.PROMPT_FORMAT
        nameLower.contains("qwen") -> "chatml"
        else -> "gemma"
    }
    @Volatile var lastUse = System.currentTimeMillis()
    val loaded: Boolean get() = llm != null

    @Synchronized
    fun ensureLoaded(): LlmInference {
        llm?.let { return it }
        val m = try { create(true) } catch (e: Throwable) { create(false) } // GPU first, CPU fallback
        llm = m
        return m
    }

    private fun create(gpu: Boolean): LlmInference {
        val b = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelFile.absolutePath)
            .setMaxTokens(maxTokens)
        if (gpu) b.setPreferredBackend(LlmInference.Backend.GPU) // delete this line if it won't compile
        return LlmInference.createFromOptions(ctx, b.build())
    }

    @Synchronized
    fun unload() {
        try { llm?.close() } catch (_: Throwable) {}
        llm = null
    }

    /** Streams the answer; [onSentence] is called for every finished sentence. */
    fun ask(history: List<Pair<String, String>>, user: String, onSentence: (String) -> Unit): String {
        val model = ensureLoaded()
        lastUse = System.currentTimeMillis()
        val full = StringBuilder()
        val pending = StringBuilder()
        val done = CountDownLatch(1)
        model.generateResponseAsync(buildPrompt(history, user)) { partial, finished ->
            if (partial != null) { full.append(partial); pending.append(partial) }
            flush(pending, finished, onSentence)
            if (finished) done.countDown()
        }
        done.await(3, TimeUnit.MINUTES)
        lastUse = System.currentTimeMillis()
        return clean(full.toString())
    }

    private fun flush(pending: StringBuilder, force: Boolean, onSentence: (String) -> Unit) {
        while (true) {
            val m = Regex("[.!?](\\s|$)").find(pending) ?: break
            val end = m.range.last + 1
            val s = clean(pending.substring(0, end))
            pending.delete(0, end)
            if (s.isNotBlank()) onSentence(s)
        }
        if (force) {
            val rest = clean(pending.toString())
            pending.setLength(0)
            if (rest.isNotBlank()) onSentence(rest)
        }
    }

    private fun clean(t: String) = t.replace(Regex("(?s)<think>.*?</think>"), "")
        .replace(Regex("[*#`_>]"), "").trim()

    private fun buildPrompt(history: List<Pair<String, String>>, user: String): String {
        val now = SimpleDateFormat("EEEE d MMMM yyyy, h:mm a", Locale.US).format(Date())
        val system = Config.SYSTEM_PROMPT + " Current date and time: $now."
        val sb = StringBuilder()
        if (format == "chatml") {
            sb.append("<|im_start|>system\n").append(system).append("<|im_end|>\n")
            for ((u, a) in history) {
                sb.append("<|im_start|>user\n").append(u).append("<|im_end|>\n")
                sb.append("<|im_start|>assistant\n").append(a).append("<|im_end|>\n")
            }
            sb.append("<|im_start|>user\n").append(user).append("<|im_end|>\n")
            sb.append("<|im_start|>assistant\n<think>\n\n</think>\n\n")
        } else {
            var first = true
            for ((u, a) in history) {
                sb.append("<start_of_turn>user\n")
                if (first) sb.append(system).append("\n\n")
                sb.append(u).append("<end_of_turn>\n<start_of_turn>model\n").append(a).append("<end_of_turn>\n")
                first = false
            }
            sb.append("<start_of_turn>user\n")
            if (first) sb.append(system).append("\n\n")
            sb.append(user).append("<end_of_turn>\n<start_of_turn>model\n")
        }
        return sb.toString()
    }
}
