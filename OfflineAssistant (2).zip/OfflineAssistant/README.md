# JARVIS for your Samsung S26 Ultra: the easy way (no Android Studio, no cables)

You do 4 things. I automated the rest.
Total time: about 30 min of mostly waiting. Phone storage used: about 2.5 GB.
Turn your VPN ON for steps 1 to 3. After setup Jarvis works offline, no VPN.

## STEP 1: Put the project on GitHub (PC browser, 5 minutes)
1. Go to github.com and create a free account.
2. Click the + at the top right > New repository. Name: jarvis. Click Create repository.
3. Click "uploading an existing file".
4. Unzip OfflineAssistant.zip on your PC. Open the unzipped folder, press Ctrl+A, and DRAG everything
   into the GitHub page (the folder .github must go too). Wait until all files are listed.
5. Click Commit changes.

## STEP 2: Let GitHub build the app (10 minutes, automatic)
1. Click the Actions tab. If it asks, click "I understand my workflows, go ahead and enable them".
2. Wait for the yellow dot to turn into a green check. (Red cross? open it, copy the error, send it to me.)
3. Go back to the main repository page. On the right, click Releases > "Jarvis (latest build)".
4. Download Jarvis.apk (on your PC, or straight on your phone).

## STEP 3: Install on the phone
1. Send Jarvis.apk to the phone (USB cable copy, or open the release page on the phone).
2. Tap the file. Android asks to allow installs from this source: allow it.
3. If Play Protect warns: More details > Install anyway.

## STEP 4: Tap the big button
Open Jarvis. One big button always does the next thing:
1. Allow permissions (say yes to everything).
2. Display over other apps: switch Jarvis ON, go back.
3. Download Jarvis (about 2.3 GB: ears, British voice, offline brain). Keep the screen open and VPN on.
   If it stops, just tap the button again: it continues where it stopped.
4. START JARVIS. He says: "Good evening, sir. Jarvis is online."

## Keep him alive with the screen off (30 seconds)
- Settings > Apps > Jarvis > Battery > Unrestricted.
- Settings > Battery > Background usage limits: Jarvis must NOT be in Sleeping/Deep sleeping apps.
- Recent apps screen: tap Jarvis icon > Keep open.
- After a phone restart: open Jarvis and tap the big button.

## What to say
"Hey Jarvis" ... "Yes, sir?" ...
- set a timer for ten minutes / set an alarm for seven thirty a m
- open WhatsApp / call Mom (he asks Shall I? say yes) / text John saying I will be late
- flashlight on / volume up / mute / what's the time / battery level
- anything else: jokes, questions, ideas (offline brain)

## Make him yours
GitHub: open app/src/main/java/com/example/voiceassistant/Config.kt > pencil icon > change > Commit.
GitHub rebuilds the app by itself in ~10 minutes; install the new Jarvis.apk over the old one
(models stay). Voice: VOICE_ID 9 = George (British), 10 = Lewis. Personality: SYSTEM_PROMPT.

## If something goes wrong
- Build has a red cross: open the failed run, copy the red error text, send it to me.
- Download keeps failing: VPN on, free space 4 GB+, tap the button again.
- He does not react to "Hey Jarvis": the status line shows "(heard: ...)". If he heard "hey travis",
  add that spelling to WAKE_REGEX in Config.kt.
- Chat answers odd or the brain will not load: tell me the exact message in the app.

Honest limits: small offline brain (good, not ChatGPT-level), no live news/weather, cannot toggle
Wi-Fi/Bluetooth (Android forbids it). I could not test-build this myself, so the first GitHub build may
need one fix; send me the error and I will correct it.
