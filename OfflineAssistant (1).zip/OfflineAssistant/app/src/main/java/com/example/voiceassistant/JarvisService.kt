package com.example.voiceassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.util.Calendar
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** The always-on part: listens for "Hey Jarvis", then acts or chats. */
class JarvisService : Service(), RecognitionListener {

    private enum class State { IDLE, AWAKE, CONFIRM, BUSY }

    companion object {
        const val ACTION_STOP = "jarvis.STOP"
        const val ACTION_TEST_VOICE = "jarvis.TEST_VOICE"
        const val ACTION_TEXT = "jarvis.TEXT"
        const val ACTION_WAKE = "jarvis.WAKE"
        const val ACTION_TEST_BRAIN = "jarvis.TEST_BRAIN"
        const val ACTION_PHOTO = "jarvis.PHOTO"
        private const val CHANNEL = "jarvis"
        @Volatile var running = false
    }

    private val worker = Executors.newSingleThreadExecutor()
    private val scheduler = Executors.newSingleThreadScheduledExecutor()
    private var vosk: Model? = null
    private var speech: SpeechService? = null
    private var voice: Voice? = null
    private var brain: Brain? = null
    private var wakeLock: PowerManager.WakeLock? = null
    @Volatile private var state = State.IDLE
    @Volatile private var deadline = 0L
    private var pending: Actions.Act? = null
    private val history = ArrayDeque<Pair<String, String>>()
    private var started = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_TEST_VOICE -> {
                if (started) {
                    val msg = "Voice test, sir. If you can hear me, my voice works."
                    Bus.log("Jarvis: $msg")
                    voice?.say(msg)
                }
                return START_STICKY
            }
            ACTION_TEXT -> {
                val txt = intent?.getStringExtra("text")?.lowercase()?.trim().orEmpty()
                if (started && txt.isNotEmpty()) worker.execute {
                    if (state == State.IDLE) runCommand(txt) else Bus.log("I am busy, try again in a moment.")
                }
                return START_STICKY
            }
            ACTION_PHOTO -> {
                val path = intent?.getStringExtra("path")
                val q = intent?.getStringExtra("text") ?: "Describe this photo."
                if (started && path != null) worker.execute {
                    if (state == State.IDLE) analyzePhoto(path, q) else Bus.log("I am busy, try again in a moment.")
                }
                return START_STICKY
            }
            ACTION_TEST_BRAIN -> {
                if (started) worker.execute { testBrain() }
                return START_STICKY
            }
            ACTION_WAKE -> {
                if (started) worker.execute { if (state == State.IDLE) wake() }
                return START_STICKY
            }
        }
        goForeground()
        if (!started) {
            started = true
            running = true
            worker.execute { boot() }
        }
        return START_STICKY
    }

    // ---------------------------------------------------------------- startup
    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, JarvisService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Hey Jarvis\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop
                ).build()
            )
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun boot() {
        try {
            Config.load(this)
            wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:listen").apply { acquire() }

            val base = getExternalFilesDir(null)!!
            val voskDir = File(base, "vosk-model")
            val kokoroDir = File(base, "kokoro")
            val llmFile = Setup.brainFile(this)
            val missing = ArrayList<String>()
            if (!voskDir.exists()) missing += "vosk-model"
            if (!File(kokoroDir, "model.onnx").exists()) missing += "kokoro"
            if (llmFile == null) missing += "brain"
            if (missing.isNotEmpty()) {
                Bus.setStatus("Missing: ${missing.joinToString()}")
                Bus.log("Open the Jarvis app and tap the big button to download what is missing.")
                stopSelf()
                return
            }

            Bus.setStatus("Loading ears...")
            vosk = Model(voskDir.absolutePath)

            Bus.setStatus("Loading voice...")
            val kokoro = OfflineTtsKokoroModelConfig(
                model = File(kokoroDir, "model.onnx").absolutePath,
                voices = File(kokoroDir, "voices.bin").absolutePath,
                tokens = File(kokoroDir, "tokens.txt").absolutePath,
                dataDir = File(kokoroDir, "espeak-ng-data").absolutePath,
            )
            val cfg = OfflineTtsConfig(
                model = OfflineTtsModelConfig(kokoro = kokoro, numThreads = 4, debug = false, provider = "cpu")
            )
            voice = Voice(OfflineTts(config = cfg))
            Actions.followUp = { msg -> announce(msg) }
            brain = Brain(this, llmFile!!)
            Bus.log("Brain file: ${llmFile.name} (${llmFile.length() / 1_000_000} MB)")

            scheduler.scheduleWithFixedDelay({
                val b = brain
                if (b != null && b.loaded && state == State.IDLE &&
                    System.currentTimeMillis() - b.lastUse > Config.UNLOAD_BRAIN_AFTER_MINUTES * 60_000L
                ) b.unload()
            }, 1, 1, TimeUnit.MINUTES)

            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val greet = when { hour < 12 -> "Good morning"; hour < 18 -> "Good afternoon"; else -> "Good evening" }
            Bus.setStatus("Online")
            Bus.log("Jarvis: $greet, sir. Jarvis is online.")
            state = State.BUSY
            voice!!.say("$greet, sir. Jarvis is online.") {
                startListening()
                state = State.IDLE
            }
        } catch (e: Throwable) {
            Bus.setStatus("Startup error: ${e.message}")
            Bus.log("Startup error: ${e.message}")
            stopSelf()
        }
    }

    // ---------------------------------------------------------------- listening
    private fun startListening() {
        val m = vosk ?: return
        speech = SpeechService(Recognizer(m, 16000f), 16000f).also { it.startListening(this) }
        Bus.setStatus("Listening for \"Hey Jarvis\"")
    }

    private fun pause() { speech?.setPause(true) }
    private fun resume() {
        speech?.reset()
        speech?.setPause(false)
    }

    override fun onPartialResult(hypothesis: String?) {}
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(e: Exception?) { Bus.setStatus("Mic error: ${e?.message}") }
    override fun onTimeout() {}

    override fun onResult(hypothesis: String?) {
        val text = JSONObject(hypothesis ?: return).optString("text").trim()
        if (text.isBlank()) return
        worker.execute { handleHeard(text.lowercase()) }
    }

    // ---------------------------------------------------------------- brain of the service
    private fun handleHeard(t: String) {
        if (state == State.BUSY) return
        val now = System.currentTimeMillis()

        if (state == State.CONFIRM) {
            if (now <= deadline) { answerConfirmation(t); return }
            state = State.IDLE; pending = null
        }
        if (state == State.AWAKE) {
            if (now <= deadline) { runCommand(t); return }
            state = State.IDLE
        }

        val end = Wake.find(t)
        if (end < 0) {
            Bus.log("heard: $t")
            Bus.setStatus("Listening for \"Hey Jarvis\"  (heard: $t)")
            return
        }
        val rest = t.substring(end).trim()
        if (rest.isBlank()) wake() else runCommand(rest)
    }

    private fun wake() {
        state = State.BUSY
        pause()
        Bus.log("(wake word heard)")
        voice?.say("Yes, sir?") {
            deadline = System.currentTimeMillis() + Config.AWAKE_SECONDS * 1000L
            state = State.AWAKE
            Bus.setStatus("Yes, sir? ...")
            resume()
        }
    }

    private fun answerConfirmation(t: String) {
        val yes = Regex("\\b(yes|yeah|yep|sure|confirm|proceed|do it|go ahead|send it|please)\\b").containsMatchIn(t)
        val no = Regex("\\b(no|nope|cancel|stop|don't|never mind)\\b").containsMatchIn(t)
        val act = pending
        pending = null
        state = State.BUSY
        pause()
        if (yes && !no && act != null) {
            val reply = try { act.run() } catch (e: Throwable) { "I am afraid that failed, sir." }
            sayThenIdle(reply)
        } else {
            sayThenIdle("Very well, sir. Cancelled.")
        }
    }

    private fun runCommand(cmd: String) {
        state = State.BUSY
        pause()
        Bus.log("You: $cmd")
        Bus.setStatus("Working...")

        if (Regex("^(stop|cancel|never mind|nevermind|that's all|thank you|thanks)\\s*$").containsMatchIn(cmd)) {
            sayThenIdle("Very well, sir.")
            return
        }

        val act = try { Actions.parse(this, cmd) } catch (e: Throwable) { null }
        if (act != null) {
            if (act.confirm != null) {
                pending = act
                Bus.log("Jarvis: ${act.confirm}")
                voice?.say(act.confirm) {
                    deadline = System.currentTimeMillis() + Config.AWAKE_SECONDS * 1000L
                    state = State.CONFIRM
                    Bus.setStatus("Waiting for yes or no...")
                    resume()
                }
            } else {
                val reply = try { act.run() } catch (e: Throwable) { "I am afraid that did not work, sir." }
                sayThenIdle(reply)
            }
            return
        }
        chat(cmd)
    }

    private fun sayThenIdle(text: String) {
        Bus.log("Jarvis: $text")
        voice?.say(text) { goIdle() }
    }

    private fun goIdle() {
        state = State.IDLE
        Bus.setStatus("Listening for \"Hey Jarvis\"")
        resume()
    }

    private fun chat(cmd: String) {
        val v = voice ?: return
        val b = brain ?: return
        v.begin()
        if (!b.loaded) v.enqueue("One moment, sir.")
        val reply = try {
            b.ask(history.toList(), cmd) { v.enqueue(it) }
        } catch (e: Throwable) {
            val m = e.message ?: "unknown error"
            Bus.log("Brain error: ${m.take(300)}")
            Bus.log("Tip: open the menu (top right) and tap Test brain, or Repair brain.")
            if (Bus.brainError == null) Bus.brainError = m.take(100)
            val damaged = m.contains("deleted")
            // graceful fallback: search the web so the question is not lost
            if (!damaged) try { Actions.webSearch(this, cmd) } catch (_: Throwable) {}
            v.enqueue(
                if (damaged) "My brain file was damaged, sir. Please open the app and tap the big button to download a fresh one."
                else "My offline brain is not working, sir, so I have searched the web for that. The details are in the app."
            )
            ""
        }
        if (reply.isNotBlank()) {
            Bus.log("Jarvis: $reply")
            history.addLast(cmd to reply)
            while (history.size > Config.HISTORY_TURNS) history.removeFirst()
        }
        v.end { goIdle() }
    }

    /** Looks at a photo with the brain and speaks what it sees. */
    private fun analyzePhoto(path: String, question: String) {
        val v = voice ?: return
        val b = brain ?: return
        state = State.BUSY
        pause()
        Bus.log("You: \uD83D\uDCF7 $question")
        Bus.setStatus("Working… looking at your photo")
        v.begin()
        if (!b.loaded) v.enqueue("One moment, sir, let me have a look.")
        val reply = try {
            b.askImage(path, question) { v.enqueue(it) }
        } catch (e: Throwable) {
            val m = e.message ?: "unknown error"
            Bus.log("Photo error: ${m.take(300)}")
            v.enqueue("I am afraid I could not look at that photo, sir. The details are in the app.")
            ""
        }
        if (reply.isNotBlank()) Bus.log("Jarvis: $reply")
        v.end { goIdle() }
    }

    /** Loads the brain and asks it one thing, so the exact error (if any) shows in the chat. */
    private fun testBrain() {
        val b = brain ?: return
        if (state != State.IDLE) { Bus.log("I am busy, try again in a moment."); return }
        state = State.BUSY
        try {
            Bus.log("Testing the brain… (the first load can take up to a minute)")
            Bus.setStatus("Working… testing brain")
            val t0 = System.currentTimeMillis()
            b.ensureLoaded()
            Bus.log("Brain loaded in ${(System.currentTimeMillis() - t0) / 1000} s.")
            val reply = b.ask(emptyList(), "Say hello in one short sentence.") { }
            Bus.log("Jarvis: $reply")
            Bus.log("Brain test passed.")
        } catch (e: Throwable) {
            Bus.log("Brain error: ${(e.message ?: "unknown").take(300)}")
        }
        state = State.IDLE
        Bus.setStatus("Listening for \"Hey Jarvis\"")
    }

    /** Speaks something on our own initiative (only when idle). */
    private fun announce(msg: String) {
        worker.execute {
            Bus.log("Jarvis: $msg")
            if (state == State.IDLE) {
                state = State.BUSY
                pause()
                voice?.say(msg) { goIdle() }
            }
        }
    }

    // ---------------------------------------------------------------- shutdown
    override fun onDestroy() {
        running = false
        Actions.followUp = null
        try { speech?.stop(); speech?.shutdown() } catch (_: Throwable) {}
        voice?.release()
        brain?.unload()
        scheduler.shutdownNow()
        worker.shutdownNow()
        try { wakeLock?.release() } catch (_: Throwable) {}
        Bus.setStatus("Stopped")
        super.onDestroy()
    }
}
