package com.example.voiceassistant

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.k2fsa.sherpa.onnx.OfflineTts
import java.util.concurrent.Executors

/** Offline neural voice. All calls are queued, so sentences play in order. */
class Voice(private val tts: OfflineTts, private val speakerId: Int, private val speed: Float) {
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var stopFlag = false
    private var track: AudioTrack? = null
    private var frames = 0L

    fun begin() = exec.execute { stopFlag = false; open() }
    fun enqueue(sentence: String) = exec.execute { play(sentence) }
    fun end(onDone: () -> Unit = {}) = exec.execute {
        close()
        try { onDone() } catch (_: Throwable) {}
    }

    fun say(text: String, onDone: () -> Unit = {}) {
        begin(); enqueue(text); end(onDone)
    }

    fun stop() {
        stopFlag = true
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
    }

    fun release() {
        stop()
        exec.shutdown()
        try { tts.release() } catch (_: Throwable) {}
    }

    private fun open() {
        val sr = tts.sampleRate()
        val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBuf * 4)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        frames = 0
        track = t
        t.play()
    }

    private fun play(sentence: String) {
        val t = track ?: return
        if (stopFlag) return
        val audio = tts.generate(sentence, speakerId, speed)
        if (stopFlag) return
        t.write(audio.samples, 0, audio.samples.size, AudioTrack.WRITE_BLOCKING)
        frames += audio.samples.size
    }

    private fun close() {
        val t = track ?: return
        try {
            // wait until everything written has really been played
            val limit = System.currentTimeMillis() + 60_000
            while (!stopFlag && t.playbackHeadPosition < frames && System.currentTimeMillis() < limit) {
                Thread.sleep(30)
            }
            t.stop()
        } catch (_: Exception) {}
        t.release()
        track = null
    }
}
