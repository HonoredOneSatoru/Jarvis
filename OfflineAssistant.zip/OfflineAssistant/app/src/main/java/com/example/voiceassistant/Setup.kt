package com.example.voiceassistant

import android.content.Context
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/** Downloads ears, voice and brain INSIDE the app, and checks that they are intact. */
object Setup {

    private const val VOSK_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private const val VOSK_BIG_URL = "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22-lgraph.zip"

    private const val KOKORO_PATH =
        "github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-en-v0_19.tar.bz2"
    private val KOKORO_URLS = listOf(
        "https://$KOKORO_PATH",
        "https://ghfast.top/https://$KOKORO_PATH",
        "https://gh-proxy.com/https://$KOKORO_PATH"
    )

    private const val BRAIN_REPO = "litert-community/Qwen2.5-1.5B-Instruct/resolve/main"

    /** Tried in this order. The second value is the file's known SHA-256 (null = ask the server for it). */
    private val BRAIN_FILES: List<Pair<String, String?>> = listOf(
        "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task" to
            "8d867a7c93a6acf2892f08e0174e2f6f351ad256b7e3cfb6d6cd9c89794b42e0",
        "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.task" to null,
        "Qwen2.5-1.5B-Instruct_seq128_q8_ekv1280.task" to null,
        "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm" to null
    )

    private fun brainUrls(name: String) = listOf(
        "https://hf-mirror.com/$BRAIN_REPO/$name",
        "https://huggingface.co/$BRAIN_REPO/$name"
    )

    private fun isBrainName(n: String) = n.endsWith(".task") || n.endsWith(".litertlm")

    fun baseDir(ctx: Context): File = ctx.getExternalFilesDir(null)!!
    fun voskDir(ctx: Context) = File(baseDir(ctx), "vosk-model")
    fun kokoroDir(ctx: Context) = File(baseDir(ctx), "kokoro")

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("jarvis_setup", Context.MODE_PRIVATE)
    fun badBrains(ctx: Context): Set<String> = prefs(ctx).getStringSet("bad", emptySet()) ?: emptySet()
    fun markBad(ctx: Context, name: String) {
        prefs(ctx).edit().putStringSet("bad", badBrains(ctx) + name).apply()
    }
    fun isVerified(ctx: Context, name: String) = prefs(ctx).getBoolean("ok_$name", false)

    // ------------------------------------------------------------------ brain health
    private val validCache = HashMap<String, Boolean>()

    /** A .task file is a zip: if its table of contents cannot be read, the download was cut short. */
    fun isValidBrain(f: File): Boolean {
        val key = f.path + "|" + f.length() + "|" + f.lastModified()
        validCache[key]?.let { return it }
        val ok = try {
            if (f.name.endsWith(".task")) ZipFile(f).close()
            f.length() > 200_000_000L
        } catch (e: Exception) {
            false
        }
        validCache[key] = ok
        return ok
    }

    /** Any intact .task or .litertlm file in the app folder counts as the brain (so you can swap models). */
    fun brainFile(ctx: Context): File? =
        baseDir(ctx).listFiles()?.firstOrNull { it.isFile && isBrainName(it.name) && isValidBrain(it) }

    /** Deletes every brain file and forgets which ones failed, so the next download starts fresh. */
    fun resetBrain(ctx: Context) {
        baseDir(ctx).listFiles()
            ?.filter { isBrainName(it.name) || (it.name.endsWith(".part") && isBrainName(it.name.removeSuffix(".part"))) }
            ?.forEach { it.delete() }
        prefs(ctx).edit().clear().apply()
        validCache.clear()
        Bus.brainError = null
    }

    fun missing(ctx: Context): List<String> {
        val m = ArrayList<String>()
        if (!File(voskDir(ctx), "am").isDirectory) m += "ears"
        if (!File(kokoroDir(ctx), "model.onnx").exists()) m += "voice"
        if (brainFile(ctx) == null) m += "brain"
        return m
    }

    // ------------------------------------------------------------------ main setup
    fun run(ctx: Context) {
        val base = baseDir(ctx)
        if (missing(ctx).isNotEmpty() && base.usableSpace < 3_500_000_000L) {
            throw IOException("Not enough free space. Free about 4 GB on the phone and tap the button again.")
        }

        if (!File(voskDir(ctx), "am").isDirectory) {
            fetchAndUnpack(listOf(VOSK_URL), File(base, "ears.zip"), "Ears (1/3)", "Unpacking ears...") {
                unzipStripped(it, voskDir(ctx))
            }
        }

        if (!File(kokoroDir(ctx), "model.onnx").exists()) {
            fetchAndUnpack(KOKORO_URLS, File(base, "voice.tar.bz2"), "Voice (2/3)", "Unpacking voice (1-2 minutes)...") {
                untarBz2Stripped(it, kokoroDir(ctx))
            }
        }

        // remove damaged brain files so they get downloaded again
        base.listFiles()
            ?.filter { it.isFile && isBrainName(it.name) && !isValidBrain(it) }
            ?.forEach { it.delete() }

        if (brainFile(ctx) == null) {
            var last: Exception? = null
            var ok = false
            for ((name, sha) in BRAIN_FILES) {
                if (name in badBrains(ctx)) continue
                try {
                    val f = File(base, name)
                    download(brainUrls(name), f, "Brain (3/3)")
                    verifyBrain(ctx, f, brainUrls(name), sha)
                    ok = true
                    break
                } catch (e: Exception) {
                    last = e
                    Bus.log("Brain file $name: ${e.message}")
                    val m = e.message ?: ""
                    if (m.contains("integrity") || m.contains("damaged")) throw e
                }
            }
            if (!ok) throw last ?: IOException("No compatible brain file is left. Use the menu: Import brain file.")
        }
        Bus.log("Download complete.")
    }

    /** Optional: a larger, more accurate speech-recognition model (about 130 MB). */
    fun upgradeEars(ctx: Context) {
        val base = baseDir(ctx)
        if (base.usableSpace < 800_000_000L) throw IOException("Not enough free space for the better ears.")
        fetchAndUnpack(listOf(VOSK_BIG_URL), File(base, "ears-big.zip"), "Better ears", "Unpacking better ears...") {
            unzipStripped(it, voskDir(ctx))
        }
        Bus.log("Better ears installed. Tap the big button to start Jarvis.")
    }

    /** Downloads an archive and unpacks it. If the archive is damaged, deletes it and tries once more. */
    private fun fetchAndUnpack(urls: List<String>, archive: File, label: String, unpackMsg: String, unpack: (File) -> Unit) {
        var attempt = 0
        while (true) {
            attempt++
            download(urls, archive, label)
            try {
                Bus.setStatus(unpackMsg)
                unpack(archive)
                archive.delete()
                return
            } catch (e: Exception) {
                archive.delete()
                File(archive.path + ".part").delete()
                Bus.log("$label: the file arrived damaged (${e.message}).")
                if (attempt >= 2) {
                    throw IOException("$label keeps arriving damaged. Try another VPN server, then tap the button again.")
                }
                Bus.log("Downloading it again...")
            }
        }
    }

    // ------------------------------------------------------------------ download with automatic resume
    private fun download(urls: List<String>, dest: File, label: String) {
        if (dest.exists()) return
        val part = File(dest.path + ".part")
        var last: Exception? = null
        for (u in urls) {
            var stalls = 0      // attempts in a row that brought no new data
            var tries = 0
            while (stalls < 4 && tries < 80) {
                tries++
                val before = if (part.exists()) part.length() else 0L
                try {
                    fetch(u, part, label)
                    if (!part.renameTo(dest)) throw IOException("could not save $label")
                    return
                } catch (e: Exception) {
                    last = e
                    val after = if (part.exists()) part.length() else 0L
                    if (after > before) stalls = 0 else stalls++
                    if (e.message?.startsWith("HTTP 4") == true) break   // not found / refused: try the next address
                    Bus.setStatus("$label: connection hiccup, resuming...")
                    try { Thread.sleep(2000) } catch (_: InterruptedException) {}
                }
            }
            Bus.log("$label: ${hostOf(u)} failed (${last?.message}).")
        }
        throw last ?: IOException("no download address worked")
    }

    private fun hostOf(u: String) = try { URL(u).host } catch (_: Exception) { u }

    private fun fetch(url: String, part: File, label: String) {
        var have = if (part.exists()) part.length() else 0L
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "JarvisSetup/1.0")
        c.setRequestProperty("Accept-Encoding", "identity")   // no transparent compression: it corrupts resumed downloads
        if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
        val code = c.responseCode
        if (code == 416) return                      // already complete
        if (code != 200 && code != 206) throw IOException("HTTP $code")
        val append = code == 206
        if (!append) have = 0
        val len = c.contentLengthLong
        val total = if (len > 0) len + have else 0L

        c.inputStream.use { input ->
            FileOutputStream(part, append).use { out ->
                val buf = ByteArray(256 * 1024)
                var done = have
                var lastShow = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    val now = System.currentTimeMillis()
                    if (now - lastShow > 700) {
                        lastShow = now
                        val mb = done / 1_000_000
                        Bus.setStatus(
                            if (total > 0) "$label: ${done * 100 / total}%  ($mb of ${total / 1_000_000} MB)"
                            else "$label: $mb MB"
                        )
                    }
                }
            }
        }
        if (total > 0 && part.length() < total) throw IOException("connection dropped, resuming")
    }

    // ------------------------------------------------------------------ integrity check
    private fun verifyBrain(ctx: Context, f: File, urls: List<String>, knownSha: String?) {
        if (!isValidBrain(f)) {
            f.delete()
            throw IOException("the brain file arrived damaged and was deleted. Tap the button to download it again.")
        }
        val want = knownSha ?: expectedSha(urls) ?: run {
            Bus.log("Brain downloaded (no checksum available to compare).")
            return
        }
        Bus.setStatus("Checking the brain file (about 30 seconds)...")
        val got = sha256(f)
        if (got != want) {
            f.delete()
            throw IOException("the brain file failed its integrity check and was deleted. Tap the button to download it again.")
        }
        prefs(ctx).edit().putBoolean("ok_${f.name}", true).apply()
        Bus.log("Brain file verified.")
    }

    /** Hugging Face publishes the file's SHA-256 in a header of the first (redirecting) response. */
    private fun expectedSha(urls: List<String>): String? {
        for (u in urls) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.requestMethod = "HEAD"
                c.instanceFollowRedirects = false
                c.connectTimeout = 15_000
                c.readTimeout = 15_000
                c.setRequestProperty("User-Agent", "JarvisSetup/1.0")
                c.responseCode
                val h = c.getHeaderField("X-Linked-Etag") ?: c.getHeaderField("ETag")
                c.disconnect()
                val v = h?.replace("\"", "")?.removePrefix("W/")?.lowercase()
                if (v != null && Regex("[0-9a-f]{64}").matches(v)) return v
            } catch (_: Exception) {}
        }
        return null
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(f).use { input ->
            val buf = ByteArray(1 shl 20)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    // ------------------------------------------------------------------ unpacking
    private fun safe(root: File, rel: String): File {
        val f = File(root, rel)
        if (!f.canonicalPath.startsWith(root.canonicalPath)) throw IOException("bad archive")
        return f
    }

    private fun unzipStripped(zip: File, dest: File) {
        val tmp = File(dest.path + ".tmp")
        tmp.deleteRecursively(); tmp.mkdirs()
        ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val rel = e.name.substringAfter('/', "")
                if (rel.isEmpty()) continue
                val f = safe(tmp, rel)
                if (e.isDirectory) f.mkdirs()
                else { f.parentFile?.mkdirs(); FileOutputStream(f).use { z.copyTo(it) } }
            }
        }
        dest.deleteRecursively()
        if (!tmp.renameTo(dest)) throw IOException("could not finish unpacking")
    }

    private fun untarBz2Stripped(archive: File, dest: File) {
        val tmp = File(dest.path + ".tmp")
        tmp.deleteRecursively(); tmp.mkdirs()
        TarArchiveInputStream(BZip2CompressorInputStream(BufferedInputStream(FileInputStream(archive), 1 shl 20))).use { t ->
            while (true) {
                val e = t.nextTarEntry ?: break
                val rel = e.name.substringAfter('/', "")
                if (rel.isEmpty()) continue
                val f = safe(tmp, rel)
                if (e.isDirectory) f.mkdirs()
                else if (e.isFile) { f.parentFile?.mkdirs(); FileOutputStream(f).use { t.copyTo(it) } }
            }
        }
        dest.deleteRecursively()
        if (!tmp.renameTo(dest)) throw IOException("could not finish unpacking")
    }
}
