package com.example.voiceassistant

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** The offline AI (Gemma 4 via LiteRT-LM). Loaded on first use and unloaded when idle to give RAM back. */
class Brain(private val ctx: Context, private val modelFile: File) {
    private var engine: Engine? = null
    private var chatConv: Conversation? = null
    private var turns = 0
    private var spoke = false
    @Volatile var lastUse = System.currentTimeMillis()
    val loaded: Boolean get() = engine != null

    // ------------------------------------------------------------------ loading
    @Synchronized
    fun ensureLoaded(): Engine {
        engine?.let { return it }
        var lastError: Throwable? = null
        // 1) phone GPU with vision, 2) CPU with vision, 3) CPU text only
        val attempts = listOf(
            Triple(true, true, "GPU"),
            Triple(false, true, "CPU"),
            Triple(false, false, "CPU, text only")
        )
        for ((gpu, vision, label) in attempts) {
            try {
                val e = create(gpu, vision)
                engine = e
                Bus.brainError = null
                Bus.log("Brain ready ($label).")
                return e
            } catch (t: Throwable) {
                lastError = t
                Bus.log("Brain start-up on $label failed: ${(t.message ?: t.toString()).take(160)}")
            }
        }
        val msg = (lastError?.message ?: lastError.toString())
        Bus.log("Brain file: ${modelFile.name} (${modelFile.length() / 1_000_000} MB)")
        Bus.brainError = msg.take(100)
        val low = msg.lowercase()
        if (!low.contains("memory") && !low.contains("alloc")) {
            // an intact (verified) file that will not load is the wrong kind of file for this engine: never try it again
            if (Setup.isVerified(ctx, modelFile.name)) Setup.markBad(ctx, modelFile.name)
            modelFile.delete()
            throw IllegalStateException(
                "The brain file would not load, so I deleted it. " +
                    "Open the Jarvis app and tap the big button to get a fresh one. (${msg.take(120)})"
            )
        }
        throw IllegalStateException(msg)
    }

    private fun create(gpu: Boolean, vision: Boolean): Engine {
        val cfg = if (vision) {
            EngineConfig(
                modelPath = modelFile.absolutePath,
                backend = if (gpu) Backend.GPU() else Backend.CPU(),
                visionBackend = if (gpu) Backend.GPU() else Backend.CPU(),
                cacheDir = ctx.cacheDir.path
            )
        } else {
            EngineConfig(
                modelPath = modelFile.absolutePath,
                backend = Backend.CPU(),
                cacheDir = ctx.cacheDir.path
            )
        }
        val e = Engine(cfg)
        e.initialize()
        return e
    }

    @Synchronized
    fun unload() {
        resetChat()
        try { engine?.close() } catch (_: Throwable) {}
        engine = null
    }

    // ------------------------------------------------------------------ chat
    @Synchronized
    private fun chat(e: Engine): Conversation {
        chatConv?.let { return it }
        val stamp = SimpleDateFormat("EEEE d MMMM yyyy, h:mm a", Locale.US).format(Date())
        val c = e.createConversation(
            ConversationConfig(systemInstruction = Contents.of(Config.systemPrompt + " Right now it is $stamp."))
        )
        chatConv = c
        turns = 0
        return c
    }

    @Synchronized
    private fun resetChat() {
        try { chatConv?.close() } catch (_: Throwable) {}
        chatConv = null
    }

    /** Streams the answer; [onSentence] is called for every finished sentence. (History is kept inside the conversation.) */
    fun ask(history: List<Pair<String, String>>, user: String, onSentence: (String) -> Unit): String {
        val e = ensureLoaded()
        lastUse = System.currentTimeMillis()
        val reply = try {
            stream(chat(e), Contents.of(user), onSentence)
        } catch (t: Throwable) {
            resetChat()      // a broken conversation must not poison the next question
            throw t
        }
        lastUse = System.currentTimeMillis()
        turns++
        if (turns >= 10) resetChat()   // keep the context small and fast
        return reply
    }

    /** Looks at a photo (path to a JPEG/PNG) and answers [question] about it. */
    fun askImage(path: String, question: String, onSentence: (String) -> Unit): String {
        val e = ensureLoaded()
        lastUse = System.currentTimeMillis()
        val cfg = ConversationConfig(systemInstruction = Contents.of(Config.visionPrompt))
        e.createConversation(cfg).use { conv ->
            val reply = stream(conv, Contents.of(Content.ImageFile(path), Content.Text(question)), onSentence)
            lastUse = System.currentTimeMillis()
            return reply
        }
    }

    // ------------------------------------------------------------------ streaming helpers
    private fun stream(conv: Conversation, contents: Contents, onSentence: (String) -> Unit): String {
        spoke = false
        val full = StringBuilder()
        val pending = StringBuilder()
        val done = CountDownLatch(1)
        var failure: Throwable? = null
        conv.sendMessageAsync(contents, object : MessageCallback {
            override fun onMessage(message: Message) {
                val piece = message.toString()
                if (piece.isEmpty()) return
                val so = full.toString()
                // some versions send the whole text so far instead of just the new part
                val delta = if (so.isNotEmpty() && piece.length > so.length && piece.startsWith(so)) piece.substring(so.length) else piece
                full.append(delta)
                pending.append(delta)
                flush(pending, false, onSentence)
            }

            override fun onDone() {
                flush(pending, true, onSentence)
                done.countDown()
            }

            override fun onError(throwable: Throwable) {
                failure = throwable
                done.countDown()
            }
        })
        if (!done.await(4, TimeUnit.MINUTES)) throw IllegalStateException("The brain took too long to answer.")
        failure?.let { throw it }
        return MathText.toDisplay(clean(full.toString()))
    }

    private fun flush(pending: StringBuilder, force: Boolean, onSentence: (String) -> Unit) {
        var from = 0
        while (true) {
            val m = Regex("[.!?](\\s|$)").find(pending, from) ?: break
            val lineStart = pending.lastIndexOf("\n", m.range.first) + 1
            val seg = pending.substring(lineStart, m.range.first)
            if (seg.matches(Regex("\\s*\\d{1,2}"))) {      // a list number such as "1." is not a sentence end
                from = m.range.last + 1
                continue
            }
            val end = m.range.last + 1
            emit(pending.substring(0, end), onSentence)
            pending.delete(0, end)
            from = 0
        }
        // start talking sooner: speak the first clause as soon as it is long enough
        if (!spoke && !force && pending.length > 45) {
            val c = Regex("[,;:]\\s").find(pending)
            if (c != null && c.range.first >= 25) {
                val end = c.range.last + 1
                emit(pending.substring(0, end), onSentence)
                pending.delete(0, end)
            }
        }
        if (force) {
            val rest = pending.toString()
            pending.setLength(0)
            emit(rest, onSentence)
        }
    }

    /** Sends one sentence to the voice, with maths turned into words. */
    private fun emit(raw: String, onSentence: (String) -> Unit) {
        val speech = MathText.toSpeech(MathText.toDisplay(clean(raw))).trim()
        if (speech.isNotBlank()) {
            spoke = true
            onSentence(speech)
        }
    }

    private fun clean(t: String) = t.replace(Regex("(?s)<think>.*?</think>"), "").trim()
}
