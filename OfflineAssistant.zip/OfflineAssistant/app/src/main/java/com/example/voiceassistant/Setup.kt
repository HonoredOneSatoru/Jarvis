package com.example.voiceassistant

import android.content.Context
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads ears, voice and brain INSIDE the app, so no PC and no adb are needed. */
object Setup {

    private const val VOSK_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"

    private const val KOKORO_PATH =
        "github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-en-v0_19.tar.bz2"
    private val KOKORO_URLS = listOf(
        "https://$KOKORO_PATH",
        "https://ghfast.top/https://$KOKORO_PATH",
        "https://gh-proxy.com/https://$KOKORO_PATH"
    )

    private const val BRAIN_NAME = "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm"
    private val BRAIN_URLS = listOf(
        "https://hf-mirror.com/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/$BRAIN_NAME",
        "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/$BRAIN_NAME"
    )

    fun baseDir(ctx: Context): File = ctx.getExternalFilesDir(null)!!
    fun voskDir(ctx: Context) = File(baseDir(ctx), "vosk-model")
    fun kokoroDir(ctx: Context) = File(baseDir(ctx), "kokoro")

    /** Any .task or .litertlm file in the app folder counts as the brain (so you can swap models). */
    fun brainFile(ctx: Context): File? =
        baseDir(ctx).listFiles()?.firstOrNull { it.isFile && (it.name.endsWith(".task") || it.name.endsWith(".litertlm")) }

    fun missing(ctx: Context): List<String> {
        val m = ArrayList<String>()
        if (!File(voskDir(ctx), "am").isDirectory) m += "ears"
        if (!File(kokoroDir(ctx), "model.onnx").exists()) m += "voice"
        if (brainFile(ctx) == null) m += "brain"
        return m
    }

    fun run(ctx: Context) {
        val base = baseDir(ctx)
        if (missing(ctx).isNotEmpty() && base.usableSpace < 3_500_000_000L) {
            throw IOException("Not enough free space. Free about 4 GB on the phone and tap the button again.")
        }

        if (!File(voskDir(ctx), "am").isDirectory) {
            val zip = File(base, "ears.zip")
            download(listOf(VOSK_URL), zip, "Ears (1/3)")
            Bus.setStatus("Unpacking ears...")
            unzipStripped(zip, voskDir(ctx))
            zip.delete()
        }

        if (!File(kokoroDir(ctx), "model.onnx").exists()) {
            val tar = File(base, "voice.tar.bz2")
            download(KOKORO_URLS, tar, "Voice (2/3)")
            Bus.setStatus("Unpacking voice (1-2 minutes)...")
            untarBz2Stripped(tar, kokoroDir(ctx))
            tar.delete()
        }

        if (brainFile(ctx) == null) {
            download(BRAIN_URLS, File(base, BRAIN_NAME), "Brain (3/3)")
        }
        Bus.log("Download complete.")
    }

    // ------------------------------------------------------------------ download with resume
    private fun download(urls: List<String>, dest: File, label: String) {
        if (dest.exists()) return
        val part = File(dest.path + ".part")
        var last: Exception? = null
        for (u in urls) {
            try {
                fetch(u, part, label)
                if (!part.renameTo(dest)) throw IOException("could not save $label")
                return
            } catch (e: Exception) {
                last = e
                Bus.log("$label: ${hostOf(u)} failed (${e.message}).")
            }
        }
        throw last ?: IOException("no download address worked")
    }

    private fun hostOf(u: String) = try { URL(u).host } catch (_: Exception) { u }

    private fun fetch(url: String, part: File, label: String) {
        var have = if (part.exists()) part.length() else 0L
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "JarvisSetup/1.0")
        if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
        val code = c.responseCode
        if (code == 416) return                      // already complete
        if (code != 200 && code != 206) throw IOException("HTTP $code")
        val append = code == 206
        if (!append) have = 0
        val len = c.contentLengthLong
        val total = if (len > 0) len + have else 0L

        c.inputStream.use { input ->
            FileOutputStream(part, append).use { out ->
                val buf = ByteArray(256 * 1024)
                var done = have
                var lastShow = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    val now = System.currentTimeMillis()
                    if (now - lastShow > 700) {
                        lastShow = now
                        val mb = done / 1_000_000
                        Bus.setStatus(
                            if (total > 0) "$label: ${done * 100 / total}%  ($mb of ${total / 1_000_000} MB)"
                            else "$label: $mb MB"
                        )
                    }
                }
            }
        }
        if (total > 0 && part.length() < total) throw IOException("connection dropped, tap the button again to resume")
    }

    // ------------------------------------------------------------------ unpacking
    private fun safe(root: File, rel: String): File {
        val f = File(root, rel)
        if (!f.canonicalPath.startsWith(root.canonicalPath)) throw IOException("bad archive")
        return f
    }

    private fun unzipStripped(zip: File, dest: File) {
        val tmp = File(dest.path + ".tmp")
        tmp.deleteRecursively(); tmp.mkdirs()
        ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val rel = e.name.substringAfter('/', "")
                if (rel.isEmpty()) continue
                val f = safe(tmp, rel)
                if (e.isDirectory) f.mkdirs()
                else { f.parentFile?.mkdirs(); FileOutputStream(f).use { z.copyTo(it) } }
            }
        }
        dest.deleteRecursively()
        if (!tmp.renameTo(dest)) throw IOException("could not finish unpacking")
    }

    private fun untarBz2Stripped(archive: File, dest: File) {
        val tmp = File(dest.path + ".tmp")
        tmp.deleteRecursively(); tmp.mkdirs()
        TarArchiveInputStream(BZip2CompressorInputStream(BufferedInputStream(FileInputStream(archive), 1 shl 20))).use { t ->
            while (true) {
                val e = t.nextTarEntry ?: break
                val rel = e.name.substringAfter('/', "")
                if (rel.isEmpty()) continue
                val f = safe(tmp, rel)
                if (e.isDirectory) f.mkdirs()
                else if (e.isFile) { f.parentFile?.mkdirs(); FileOutputStream(f).use { t.copyTo(it) } }
            }
        }
        dest.deleteRecursively()
        if (!tmp.renameTo(dest)) throw IOException("could not finish unpacking")
    }
}
