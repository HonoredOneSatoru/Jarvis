package com.example.voiceassistant

/** Everything you may want to tweak lives here. */
object Config {
    val SYSTEM_PROMPT =
        "You are J.A.R.V.I.S., a calm, impeccably polite British AI butler with dry wit. " +
        "Always address the user as 'sir'. Reply in one to three short spoken sentences. " +
        "Never use markdown, lists or emojis. If you do not know something, say so plainly " +
        "and never invent facts. You run fully offline on the user's phone, so you cannot " +
        "browse the internet or know today's news."

    // Wake word. Vosk may hear "jarvis" differently; add the spellings you see in the app's
    // "heard:" line, separated by | .
    val WAKE_REGEX = Regex("\\b(jarvis|jarvas|jarvus|jarves|garvis|travis|jar vis|java's)\\b")

    // Voice (Kokoro): 9 = British male "george", 10 = British male "lewis"
    const val VOICE_ID = 9
    const val VOICE_SPEED = 0.97f

    // Brain
    const val PROMPT_FORMAT = "auto"    // "auto" picks by model name; or force "gemma" / "chatml"
    const val MAX_TOKENS = 4096     // only used if the model file name has no "ekvNNNN" in it
    const val HISTORY_TURNS = 6
    const val UNLOAD_BRAIN_AFTER_MINUTES = 10  // frees ~4 GB of RAM when idle

    // Behaviour
    const val AWAKE_SECONDS = 8
    const val CONFIRM_CALLS = true
    const val CONFIRM_TEXTS = true
}
