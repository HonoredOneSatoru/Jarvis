package com.example.voiceassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Downloads Jarvis in the background, so you can leave the app. Only one download can run at a time. */
class SetupService : Service() {

    companion object {
        const val ACTION_INSTALL = "setup.INSTALL"
        const val ACTION_EARS = "setup.EARS"
        private const val CHANNEL = "jarvis_setup"
        private const val ID = 2
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun openApp() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
    )

    private fun build(text: String, ongoing: Boolean): Notification =
        Notification.Builder(this, CHANNEL)
            .setContentTitle(if (ongoing) "Downloading Jarvis" else "Jarvis setup")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentIntent(openApp())
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .build()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Jarvis setup", NotificationManager.IMPORTANCE_LOW))
        val first = build("Starting…", true)
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(ID, first)

        // a second tap (or a re-created screen) must never start a second download of the same files
        if (!Setup.busy.compareAndSet(false, true)) return START_NOT_STICKY

        val ears = intent?.action == ACTION_EARS
        Thread {
            var ok = false
            try {
                if (ears) Setup.upgradeEars(this) else Setup.run(this)
                ok = true
            } catch (e: Throwable) {
                Bus.log("Problem: ${e.message}")
                Bus.setStatus("Stopped. Read the message above, then tap the button to try again (it resumes).")
            }
            Setup.busy.set(false)
            Bus.listener?.invoke()
            stopForeground(STOP_FOREGROUND_REMOVE)
            nm.cancel(ID)
            nm.notify(
                ID + 1,
                build(if (ok) "Download finished. Tap to open Jarvis." else "Download stopped. Tap to open Jarvis and resume.", false)
            )
            stopSelf()
        }.start()

        Thread {
            while (true) {
                try { Thread.sleep(2000) } catch (_: InterruptedException) { break }
                if (!Setup.busy.get()) break
                nm.notify(ID, build(Bus.statusText, true))
            }
        }.start()
        return START_NOT_STICKY
    }
}
