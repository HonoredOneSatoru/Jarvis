package com.example.voiceassistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/** Chat-style home screen. One big button always does the next thing that is needed. */
class MainActivity : Activity() {

    private val PICK_BRAIN = 42

    private val cBg = Color.parseColor("#0D1117")
    private val cCard = Color.parseColor("#161B22")
    private val cText = Color.parseColor("#E6EDF3")
    private val cMuted = Color.parseColor("#8B949E")
    private val cAccent = Color.parseColor("#2F81F7")
    private val cGreen = Color.parseColor("#2EA043")
    private val cRed = Color.parseColor("#F85149")
    private val cOrange = Color.parseColor("#D29922")
    private val cGray = Color.parseColor("#484F58")

    private lateinit var statusPill: TextView
    private lateinit var statusLine: TextView
    private lateinit var setupCard: LinearLayout
    private lateinit var checkRows: LinearLayout
    private lateinit var bigButton: Button
    private lateinit var scroll: ScrollView
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText

    @Volatile private var downloading = false
    private var shown = 0
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    private val perms: Array<String> by lazy {
        val l = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        l.toTypedArray()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int = 14) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    // ================================================================== UI
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Config.load(this)
        actionBar?.hide()
        window.setBackgroundDrawable(ColorDrawable(cBg))
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
        }
        root.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(dp(16), insets.systemWindowInsetTop + dp(8), dp(16), insets.systemWindowInsetBottom + dp(8))
            insets
        }

        // ---- header ----
        val title = TextView(this).apply {
            text = "JARVIS"
            textSize = 22f
            setTextColor(cText)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
        }
        statusPill = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(5), dp(12), dp(5))
        }
        val menu = TextView(this).apply {
            text = "⋮"
            textSize = 26f
            setTextColor(cText)
            setPadding(dp(14), 0, dp(4), 0)
            setOnClickListener { showMenu(it) }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(statusPill)
            addView(menu)
        }
        statusLine = TextView(this).apply {
            textSize = 12f
            setTextColor(cMuted)
            setPadding(0, dp(6), 0, dp(8))
        }

        // ---- setup card ----
        setupCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(cCard)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val setupTitle = TextView(this).apply {
            text = "Getting Jarvis ready"
            textSize = 15f
            setTextColor(cText)
            typeface = Typeface.DEFAULT_BOLD
        }
        checkRows = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, 0)
        }
        bigButton = Button(this).apply {
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = round(cAccent)
            setOnClickListener { nextStep() }
        }
        setupCard.addView(setupTitle)
        setupCard.addView(checkRows)
        setupCard.addView(bigButton, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })

        // ---- conversation ----
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(chat)
        }
        chat.addView(TextView(this).apply {
            text = "Say “Hey Jarvis”, then try:\n" +
                "•  set a timer for ten minutes\n" +
                "•  open WhatsApp\n" +
                "•  play Blinding Lights on Spotify\n" +
                "•  call Mom  /  text John saying I am late\n" +
                "•  tell me a joke  /  what is gravity\n" +
                "You can also type below or tap a chip."
            textSize = 13f
            setTextColor(cMuted)
            background = round(cCard)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        })

        // ---- quick chips ----
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(4))
        }
        listOf(
            "What time is it" to "what time is it",
            "Tell me a joke" to "tell me a joke",
            "Battery" to "battery level",
            "Flashlight" to "flashlight on",
            "Open Spotify" to "open spotify",
            "Pause" to "pause",
            "Next song" to "next song"
        ).forEach { (label, cmd) ->
            chips.addView(chip(label) { svc(JarvisService.ACTION_TEXT, cmd) },
                LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        val chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chips)
        }

        // ---- input row ----
        input = EditText(this).apply {
            hint = "Type a command…"
            setHintTextColor(cMuted)
            setTextColor(cText)
            textSize = 15f
            setSingleLine(true)
            background = round(cCard, 24)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> submit(); true }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, 0)
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(roundBtn("➤", cAccent) { submit() })
            addView(roundBtn("🎙", cGreen) { svc(JarvisService.ACTION_WAKE, null) })
        }

        root.addView(header)
        root.addView(statusLine)
        root.addView(setupCard)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(chipScroll)
        root.addView(row)
        setContentView(root)
    }

    private fun chip(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(cText)
        background = round(cCard, 20)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { onClick() }
    }

    private fun roundBtn(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
        this.text = label
        textSize = 18f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = round(color, 24)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { leftMargin = dp(8) }
    }

    override fun onResume() {
        super.onResume()
        Bus.listener = { runOnUiThread { render() } }
        render()
    }

    override fun onPause() {
        Bus.listener = null
        super.onPause()
    }

    // ================================================================== state -> screen
    private fun permsDone() =
        prefs.getBoolean("asked", false) &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun ready() = permsDone() && Settings.canDrawOverlays(this) && Setup.missing(this).isEmpty()

    private fun label(): String = when {
        downloading -> "Working… keep this screen open"
        !permsDone() -> "1/4  Allow permissions"
        !Settings.canDrawOverlays(this) -> "2/4  Allow “Display over other apps”"
        Setup.missing(this).isNotEmpty() -> "3/4  Download Jarvis (about 2 GB)"
        JarvisService.running -> "Restart Jarvis"
        else -> "4/4  START JARVIS"
    }

    private fun pill(): Pair<String, Int> {
        val s = Bus.statusText
        return when {
            downloading -> "Working" to cOrange
            !ready() -> "Setup needed" to cOrange
            !JarvisService.running -> "Stopped" to cGray
            s.contains("Working") -> "Thinking" to cAccent
            s.contains("Yes, sir") -> "Awake" to cAccent
            s.startsWith("Listening") -> "Listening" to cGreen
            else -> s.take(16) to cAccent
        }
    }

    private fun render() {
        val (txt, col) = pill()
        statusPill.text = txt
        statusPill.background = round(col, 20)
        statusLine.text = Bus.statusText

        setupCard.visibility = if (ready() && JarvisService.running) View.GONE else View.VISIBLE
        buildChecks()
        bigButton.text = label()
        drawNewMessages()
    }

    private fun buildChecks() {
        checkRows.removeAllViews()
        fun row(ok: Boolean, name: String, detail: String? = null) {
            checkRows.addView(TextView(this).apply {
                this.text = (if (ok) "✔  " else "✖  ") + name + (if (detail != null) "\n      $detail" else "")
                textSize = 14f
                setTextColor(if (ok) cGreen else cRed)
                setPadding(0, dp(3), 0, dp(3))
            })
        }
        row(permsDone(), "Permissions")
        row(Settings.canDrawOverlays(this), "Display over other apps (timers, apps)")
        row(File(Setup.voskDir(this), "am").isDirectory, "Ears: speech recognition")
        row(File(Setup.kokoroDir(this), "model.onnx").exists(), "Voice: British butler")
        val b = Setup.brainFile(this)
        when {
            b != null && Bus.brainError == null ->
                row(true, "Brain: offline AI", "${b.name.substringBefore('_')} · ${b.length() / 1_000_000} MB")
            b != null -> row(false, "Brain needs repair", "Menu ⋮ → Repair brain")
            else -> row(false, "Brain: offline AI (not downloaded)")
        }
    }

    private fun drawNewMessages() {
        var snapshot: List<String> = emptyList()
        var total = 0
        synchronized(Bus.lines) {
            snapshot = ArrayList(Bus.lines)
            total = Bus.total
        }
        val newCount = total - shown
        if (newCount <= 0) return
        val fresh = if (newCount >= snapshot.size) snapshot else snapshot.takeLast(newCount)
        for (l in fresh) addBubble(l)
        shown = total
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addBubble(line: String) {
        val kind: Int
        val msg: String
        when {
            line.startsWith("You: ") -> { kind = 0; msg = line.removePrefix("You: ") }
            line.startsWith("Jarvis: ") -> { kind = 1; msg = line.removePrefix("Jarvis: ") }
            line.startsWith("heard: ") -> { kind = 2; msg = "🎧 " + line.removePrefix("heard: ") }
            else -> { kind = 3; msg = line }
        }
        val low = msg.lowercase()
        val bad = kind == 3 && (low.contains("error") || low.contains("problem") || low.contains("failed") ||
            low.contains("damaged") || low.contains("stopped"))
        val tv = TextView(this).apply {
            this.text = msg
            when (kind) {
                0 -> { textSize = 15f; setTextColor(Color.WHITE); background = round(cAccent, 18); setPadding(dp(14), dp(9), dp(14), dp(9)) }
                1 -> { textSize = 15f; setTextColor(cText); background = round(cCard, 18); setPadding(dp(14), dp(9), dp(14), dp(9)) }
                2 -> { textSize = 11f; setTextColor(cMuted) }
                else -> { textSize = 12f; setTextColor(if (bad) cRed else cMuted); gravity = Gravity.CENTER }
            }
            maxWidth = (resources.displayMetrics.widthPixels * 0.82).toInt()
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(if (kind == 2) 2 else 8)
        lp.gravity = when (kind) {
            0 -> Gravity.END
            1, 2 -> Gravity.START
            else -> Gravity.CENTER_HORIZONTAL
        }
        chat.addView(tv, lp)
        while (chat.childCount > 300) chat.removeViewAt(1)
    }

    // ================================================================== the one big button
    private fun nextStep() {
        when {
            downloading -> {}
            !permsDone() -> requestPermissions(perms, 1)
            !Settings.canDrawOverlays(this) -> {
                Toast.makeText(this, "Switch Jarvis ON, then come back and tap the button", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            Setup.missing(this).isNotEmpty() -> startDownload()
            JarvisService.running -> {
                stopJarvis()
                Handler(Looper.getMainLooper()).postDelayed({ startJarvis() }, 1500)
            }
            else -> startJarvis()
        }
        render()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        prefs.edit().putBoolean("asked", true).apply()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) nextStep()
        else {
            Toast.makeText(this, "Jarvis needs the microphone to work", Toast.LENGTH_LONG).show()
            prefs.edit().putBoolean("asked", false).apply()
            render()
        }
    }

    private fun startJarvis() {
        startForegroundService(Intent(this, JarvisService::class.java))
    }

    private fun stopJarvis() {
        startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_STOP))
    }

    /** Sends a test command / action to the running service. */
    private fun svc(action: String, extra: String?) {
        if (!JarvisService.running) {
            Toast.makeText(this, "Start Jarvis first (big button)", Toast.LENGTH_SHORT).show()
            return
        }
        startService(Intent(this, JarvisService::class.java).setAction(action).apply {
            if (extra != null) putExtra("text", extra)
        })
    }

    private fun submit() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        svc(JarvisService.ACTION_TEXT, t)
        input.setText("")
    }

    // ================================================================== long jobs
    /** Runs [work] on a background thread with the screen kept awake; failures show in the chat. */
    private fun runBusy(work: () -> Unit, after: (Boolean) -> Unit = {}) {
        if (downloading) return
        downloading = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        render()
        Thread {
            var ok = false
            try {
                work()
                ok = true
            } catch (e: Throwable) {
                Bus.log("Problem: ${e.message}")
                Bus.setStatus("Stopped. Read the message above, then tap the button to try again (it resumes).")
            }
            runOnUiThread {
                downloading = false
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                render()
                after(ok)
            }
        }.start()
    }

    private fun startDownload() {
        Bus.log("Downloading Jarvis (about 2 GB). Keep your VPN on and this screen open. If the connection drops it resumes by itself.")
        runBusy({ Setup.run(this) }) { ok -> if (ok) nextStep() }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_BRAIN && resultCode == RESULT_OK) data?.data?.let { importBrain(it) }
    }

    /** Copies a brain file (.task / .litertlm) that the person downloaded with the phone browser. */
    private fun importBrain(uri: Uri) {
        runBusy({
            var name = "brain.task"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = c.getString(i) ?: name
                }
            }
            if (!(name.endsWith(".task") || name.endsWith(".litertlm"))) {
                throw IOException("please pick a .task or .litertlm file (you picked $name)")
            }
            val dest = File(Setup.baseDir(this), name)
            val part = File(dest.path + ".part")
            var copied = 0L
            contentResolver.openInputStream(uri)!!.use { input ->
                FileOutputStream(part).use { out ->
                    val buf = ByteArray(256 * 1024)
                    var last = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        copied += n
                        val now = System.currentTimeMillis()
                        if (now - last > 700) { last = now; Bus.setStatus("Importing brain: ${copied / 1_000_000} MB") }
                    }
                }
            }
            dest.delete()
            if (!part.renameTo(dest)) throw IOException("could not save the file")
            if (!Setup.isValidBrain(dest)) {
                dest.delete()
                throw IOException("that file is incomplete or damaged (the browser download was cut short). Download it again.")
            }
            Bus.brainError = null
            Bus.log("Brain imported: $name (${copied / 1_000_000} MB)")
            Bus.setStatus("Brain imported.")
        })
    }

    private fun repairBrain() {
        AlertDialog.Builder(this)
            .setTitle("Repair brain")
            .setMessage("This deletes the current brain file and downloads a fresh, verified one (about 1.6 GB). Continue?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Repair") { _, _ ->
                stopJarvis()
                Setup.resetBrain(this)
                Bus.log("Brain removed. Downloading a fresh one…")
                Handler(Looper.getMainLooper()).postDelayed({ nextStep() }, 800)
            }
            .show()
    }

    private fun upgradeEars() {
        AlertDialog.Builder(this)
            .setTitle("Better speech recognition")
            .setMessage("Downloads a larger speech model (about 130 MB). He will understand you more accurately. Jarvis restarts afterwards.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Download") { _, _ ->
                stopJarvis()
                Bus.log("Downloading better ears (about 130 MB)…")
                runBusy({ Setup.upgradeEars(this) }) { ok -> if (ok) nextStep() }
            }
            .show()
    }

    // ================================================================== menu, settings, help
    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "Settings")
        m.menu.add(0, 2, 1, "Test his voice")
        m.menu.add(0, 3, 2, "Wake him now")
        m.menu.add(0, 4, 3, "What can I say?")
        m.menu.add(0, 5, 4, "Better speech recognition (+130 MB)")
        m.menu.add(0, 6, 5, "Import brain file…")
        m.menu.add(0, 7, 6, "Repair brain (download fresh)")
        m.menu.add(0, 8, 7, "Copy report for support")
        m.menu.add(0, 10, 7, "Test brain")
        m.menu.add(0, 9, 8, "Stop Jarvis")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> showSettings()
                2 -> svc(JarvisService.ACTION_TEST_VOICE, null)
                3 -> svc(JarvisService.ACTION_WAKE, null)
                4 -> showHelp()
                5 -> upgradeEars()
                6 -> {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(i, PICK_BRAIN)
                }
                7 -> repairBrain()
                8 -> copyReport()
                9 -> stopJarvis()
                10 -> svc(JarvisService.ACTION_TEST_BRAIN, null)
            }
            true
        }
        m.show()
    }

    private fun showHelp() {
        AlertDialog.Builder(this)
            .setTitle("What can I say?")
            .setMessage(
                "Start with “Hey Jarvis”, wait for “Yes, sir?”, then:\n\n" +
                    "TIMERS: set a timer for ten minutes\n" +
                    "ALARMS: set an alarm for seven thirty a m\n" +
                    "APPS: open WhatsApp\n" +
                    "MUSIC: play Blinding Lights · open Spotify and play Numb · pause · next song\n" +
                    "WEB: search for pizza near me · navigate to the airport\n" +
                    "CALLS: call Mom (he asks first)\n" +
                    "TEXTS: text John saying I will be late\n" +
                    "PHONE: flashlight on/off · volume up/down · mute · battery level\n" +
                    "FACTS: what time is it · what is the date\n" +
                    "ANYTHING ELSE: jokes, questions, advice (offline brain)"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showSettings() {
        val voices = listOf(
            "George (British male)" to 9, "Lewis (British male)" to 10,
            "Emma (British female)" to 7, "Isabella (British female)" to 8,
            "Bella (American female)" to 1, "Sky (American female)" to 4,
            "Adam (American male)" to 5, "Michael (American male)" to 6
        )
        val speeds = listOf("Slower (0.90)" to 0.90f, "Calm (0.97)" to 0.97f, "Normal (1.00)" to 1.0f, "Faster (1.10)" to 1.1f)
        val wakes = listOf("Strict (fewer false wake-ups)" to 1, "Normal" to 2, "Forgiving (wakes easily)" to 3)
        val musics = listOf("Spotify" to "com.spotify.music", "YouTube Music" to "com.google.android.apps.youtube.music")
        fun yn(b: Boolean) = if (b) "on" else "off"

        val items = arrayOf(
            "Voice: " + (voices.firstOrNull { it.second == Config.voiceId }?.first ?: "custom"),
            "Speaking speed: " + String.format("%.2f", Config.voiceSpeed),
            "Wake word: " + wakes.first { it.second == Config.wakeMaxDist.coerceIn(1, 3) }.first,
            "Music app: " + (musics.firstOrNull { it.second == Config.musicApp }?.first ?: "custom"),
            "Ask before calling: " + yn(Config.confirmCalls),
            "Ask before texting: " + yn(Config.confirmTexts)
        )
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> AlertDialog.Builder(this).setTitle("Voice")
                        .setItems(voices.map { it.first }.toTypedArray()) { _, i ->
                            Config.voiceId = voices[i].second; Config.save(this)
                            svc(JarvisService.ACTION_TEST_VOICE, null); showSettings()
                        }.show()
                    1 -> AlertDialog.Builder(this).setTitle("Speaking speed")
                        .setItems(speeds.map { it.first }.toTypedArray()) { _, i ->
                            Config.voiceSpeed = speeds[i].second; Config.save(this)
                            svc(JarvisService.ACTION_TEST_VOICE, null); showSettings()
                        }.show()
                    2 -> AlertDialog.Builder(this).setTitle("Wake word sensitivity")
                        .setItems(wakes.map { it.first }.toTypedArray()) { _, i ->
                            Config.wakeMaxDist = wakes[i].second; Config.save(this); showSettings()
                        }.show()
                    3 -> AlertDialog.Builder(this).setTitle("Music app")
                        .setItems(musics.map { it.first }.toTypedArray()) { _, i ->
                            Config.musicApp = musics[i].second; Config.save(this); showSettings()
                        }.show()
                    4 -> { Config.confirmCalls = !Config.confirmCalls; Config.save(this); showSettings() }
                    5 -> { Config.confirmTexts = !Config.confirmTexts; Config.save(this); showSettings() }
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun copyReport() {
        val sb = StringBuilder()
        sb.append("Jarvis report\n")
        sb.append("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}\n")
        val base = Setup.baseDir(this)
        sb.append("Free space: ${base.usableSpace / 1_000_000} MB\n")
        base.listFiles()?.forEach { sb.append("File: ${it.name}  ${if (it.isFile) it.length() / 1_000_000 else -1} MB\n") }
        sb.append("Valid brain: ${Setup.brainFile(this)?.name}\n")
        sb.append("Bad brains: ${Setup.badBrains(this)}\n")
        sb.append("Brain error: ${Bus.brainError}\n")
        sb.append("Status: ${Bus.statusText}\n")
        sb.append("--- last messages ---\n")
        synchronized(Bus.lines) { Bus.lines.takeLast(40).forEach { sb.append(it).append('\n') } }
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("Jarvis report", sb.toString()))
        Toast.makeText(this, "Report copied. Paste it into your message.", Toast.LENGTH_LONG).show()
    }
}
